# StockLink

Private, real-time stock sharing and ordering between wholesalers and retailers.
No npm dependencies. Needs Node 22.5 or newer. Data lives in one SQLite file.

## Try it in 30 seconds (demo mode)

    DEMO_MODE=1 npm start
    open http://localhost:3000

Tap a demo account on the login screen (password for all: Demo@1234). Invite code for the demo wholesaler: K7QM-3XRP.
Suggested walkthrough: log in as Retailer (not connected yet), enter the code, then log in as Wholesaler (verified) and approve the request, go back to the retailer and place an order, then advance it as the wholesaler.

DEMO MODE PUBLISHES LOGINS ON THE LOGIN SCREEN. Use it only for showing the product. Never put real customers on a demo-mode server.

## Run for real customers (production mode)

Set these environment variables, leave DEMO_MODE unset:

| Variable | Meaning |
|---|---|
| NODE_ENV=production | Secure cookies, HSTS |
| SESSION_SECRET | Long random string (32+ chars). Keys the invite-code hashes. Do not change after launch. |
| ADMIN_PHONE, ADMIN_PASSWORD, ADMIN_NAME | Creates your super admin on first start. Password 12+ characters. |
| DB_PATH | Path to the SQLite file. Must be on persistent disk. |
| TRUST_PROXY=1 | Set when behind Render/Railway/Fly/nginx so rate limits see the real client IP |
| PORT | Default 3000 |

Then `npm start`. New wholesalers sign up and wait in the admin Shops tab until you approve them.

## Deploy

Any host that runs Node 22 or Docker and has a persistent disk. Cheapest paths:

* Render / Railway / Fly.io: create a web service from this folder (it has a Dockerfile), add a persistent disk mounted at /data, set the variables above. Their HTTPS is automatic.
* A small VPS: `docker build -t stocklink .` then `docker run -d -p 3000:3000 -v stocklink-data:/data -e SESSION_SECRET=... -e ADMIN_PHONE=... -e ADMIN_PASSWORD=... stocklink`, with Caddy or nginx in front for HTTPS.

Always serve over HTTPS. Run exactly ONE instance (SQLite and in-memory rate limits are single-process).

## Backups

Copy the SQLite file (and secret.key if you did not set SESSION_SECRET) nightly. With the file stopped or using `sqlite3 stocklink.db ".backup backup.db"`.

## Tests

    npm test                 # 117 security and integrity checks, starts its own temp server
    node test/e2e.js         # browser test (needs Playwright and a fresh demo server on port 3111)

See SECURITY.md for what is covered and what is not.

## Not built yet (be honest with customers and investors)

* Login is phone + password. No SMS OTP, no password reset (admin must reset).
* Payments are manual: retailer pays by UPI and submits the UTR, wholesaler verifies in their bank app. No payment gateway, no automatic reconciliation.
* No Tally / billing-software stock sync. Wholesalers update counts by hand (-1 sold, +10 restock, set exact count).
* No push or WhatsApp notifications. Live updates only while the app is open.
* No GST invoices, no delivery tracking, no multi-user staff accounts per shop.
* One SQLite instance. Fine for pilots (hundreds of shops). Move to Postgres before thousands.
