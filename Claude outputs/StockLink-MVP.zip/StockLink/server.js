'use strict';
/* StockLink server: no third-party packages. Node >= 22.5 (built-in node:sqlite). */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { open, tx, audit, verifyAudit } = require('./lib/db');
const A = require('./lib/auth');
const GST = require('./lib/gstin');
const { fail, HttpError } = A;

const PUBLIC_DIR = path.join(__dirname, 'public');
const STATIC = { '/': 'index.html', '/index.html': 'index.html', '/app.js': 'app.js', '/i18n.js': 'i18n.js', '/style.css': 'style.css', '/favicon.svg': 'favicon.svg' };
const TYPES = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', svg: 'image/svg+xml' };
const DAY = 86400000;

function loadConfig(env = process.env) {
  return {
    port: Number(env.PORT || 3000), host: env.HOST || '0.0.0.0',
    dbPath: env.DB_PATH || path.join(__dirname, 'data', 'stocklink.db'),
    demo: env.DEMO_MODE === '1', prod: env.NODE_ENV === 'production', trustProxy: env.TRUST_PROXY === '1',
    secret: env.SESSION_SECRET || null,
    admin: { phone: env.ADMIN_PHONE || null, password: env.ADMIN_PASSWORD || null, name: env.ADMIN_NAME || 'Platform Admin' },
    currency: env.CURRENCY || '₹'
  };
}
function getSecret(cfg) {
  if (cfg.secret) return cfg.secret;
  const f = path.join(path.dirname(cfg.dbPath), 'secret.key');
  try { return fs.readFileSync(f, 'utf8').trim(); } catch (_) {}
  const s = crypto.randomBytes(32).toString('hex');
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}

function createApp(cfg) {
  fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
  const db = open(cfg.dbPath);
  const secret = getSecret(cfg);
  const seed = require('./seed');
  seed.ensureAdmin(db, cfg);
  if (cfg.demo) seed.seedDemoIfEmpty(db, cfg);

  const staticCache = {};
  for (const f of new Set(Object.values(STATIC))) { try { staticCache[f] = fs.readFileSync(path.join(PUBLIC_DIR, f)); } catch (_) {} }

  const clients = new Set();
  const q = (sql) => db.prepare(sql);
  const now = () => Date.now();

  /* ---------- helpers ---------- */
  function connApproved(wid, rid) {
    return !!q(`SELECT 1 FROM connections c JOIN shops w ON w.id=c.wholesaler_shop_id JOIN users u ON u.id=w.owner_id
      WHERE c.wholesaler_shop_id=? AND c.retailer_shop_id=? AND c.status='approved' AND w.verification='approved' AND u.status='active'`).get(wid, rid);
  }
  function emit(ev) {
    const payload = `event: ${ev.kind}\ndata: ${JSON.stringify(ev.data || {})}\n\n`;
    for (const c of clients) {
      let ok = c.shopId === ev.wid || (ev.rid && c.shopId === ev.rid);
      if (!ok && ev.scope === 'catalog' && c.role === 'retailer') ok = connApproved(ev.wid, c.shopId);
      if (ok) { try { c.res.write(payload); } catch (_) {} }
    }
  }
  const phoneOf = (v) => {
    if (typeof v !== 'string') fail(400, 'invalid_phone');
    const s = v.replace(/[\s-]/g, '');
    if (!/^\+?[0-9]{8,15}$/.test(s)) fail(400, 'invalid_phone');
    return s;
  };
  const rupeesToPaise = (v) => {
    const n = typeof v === 'string' ? Number(v) : v;
    if (typeof n !== 'number' || !Number.isFinite(n) || n <= 0 || n > 1000000) fail(400, 'invalid_price');
    return Math.round(n * 100);
  };
  const mediaIds = (pid) => q('SELECT id FROM media WHERE product_id=? ORDER BY sort,id').all(pid).map(r => r.id);
  function productOut(p, owner) {
    const o = { id: p.id, shop_id: p.shop_id, name: p.name, spec: p.spec, price_paise: p.price_paise, unit: p.unit, moq: p.moq,
      status: p.status, is_new: !!p.is_new, available: p.on_hand - p.reserved, verified_at: p.stock_verified_at, media: mediaIds(p.id) };
    if (owner) { o.on_hand = p.on_hand; o.reserved = p.reserved; }
    return o;
  }
  function orderOut(o, who) {
    const items = q('SELECT product_id,name_snapshot AS name,unit_price_paise,qty FROM order_items WHERE order_id=?').all(o.id);
    const history = q('SELECT status,note,ts FROM order_history WHERE order_id=? ORDER BY id').all(o.id);
    const r = q('SELECT name,city FROM shops WHERE id=?').get(o.retailer_shop_id);
    const w = q('SELECT name,city,upi_id FROM shops WHERE id=?').get(o.wholesaler_shop_id);
    const out = { id: o.id, no: o.no, status: o.status, fulfilment: o.fulfilment, address: o.address, payment_mode: o.payment_mode,
      utr: o.utr, has_proof: !!o.proof_mime, subtotal_paise: o.subtotal_paise, created_at: o.created_at, updated_at: o.updated_at,
      cancel_reason: o.cancel_reason, reserve_expires_at: o.reserve_expires_at, wholesaler_shop_id: o.wholesaler_shop_id,
      items, history, retailer: r, wholesaler: w };
    if (who === 'retailer') out.pickup_code = o.pickup_code;
    return out;
  }
  function releaseItems(orderId) {
    for (const it of q('SELECT product_id,qty FROM order_items WHERE order_id=?').all(orderId)) {
      const r = q('UPDATE products SET reserved=reserved-? WHERE id=? AND reserved>=?').run(it.qty, it.product_id, it.qty);
      if (r.changes !== 1) throw new Error('reservation_mismatch');
    }
  }
  const setStatus = (o, status, actorId, note) => {
    q('UPDATE orders SET status=?, updated_at=? WHERE id=?').run(status, now(), o.id);
    q('INSERT INTO order_history(order_id,status,actor_user_id,note,ts) VALUES(?,?,?,?,?)').run(o.id, status, actorId ?? null, note ?? null, now());
  };
  const emitStockFor = (orderId) => {
    const o = q('SELECT wholesaler_shop_id FROM orders WHERE id=?').get(orderId);
    for (const it of q('SELECT product_id FROM order_items WHERE order_id=?').all(orderId)) {
      const p = q('SELECT id,on_hand,reserved FROM products WHERE id=?').get(it.product_id);
      emit({ kind: 'stock', wid: o.wholesaler_shop_id, scope: 'catalog', data: { product_id: p.id, available: p.on_hand - p.reserved } });
    }
  };

  /* ---------- sessions ---------- */
  function startSession(res, user, ctx) {
    const token = A.newToken();
    q('INSERT INTO sessions(id,user_id,created_at,expires_at,ip,ua) VALUES(?,?,?,?,?,?)')
      .run(A.sha256(token), user.id, now(), now() + 7 * DAY, ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 200));
    res.setHeader('Set-Cookie', `sl_sid=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${7 * 86400}${cfg.prod ? '; Secure' : ''}`);
  }
  function sessionUser(req) {
    const m = /(?:^|;\s*)sl_sid=([A-Za-z0-9_-]{20,64})/.exec(req.headers.cookie || '');
    if (!m) return null;
    const row = q(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires_at>? AND u.status='active'`).get(A.sha256(m[1]), now());
    return row || null;
  }

  /* ---------- route handlers ---------- */
  const R = [];
  const route = (method, pattern, auth, handler, opts = {}) => {
    const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '(\\d+)'; }) + '$');
    R.push({ method, re, keys, auth, handler, big: !!opts.big });
  };

  route('GET', '/api/config', null, () => ({ demo: cfg.demo, currency: cfg.currency,
    accounts: cfg.demo ? [
      { role: 'retailer', label: 'Retailer (connected)', phone: '9000000004' }, { role: 'wholesaler', label: 'Wholesaler (verified)', phone: '9000000002' },
      { role: 'admin', label: 'Super admin', phone: '9000000001' }, { role: 'retailer', label: 'Retailer (not connected yet)', phone: '9000000006' }] : [],
    demo_password: cfg.demo ? 'Demo@1234' : null, demo_code: cfg.demo ? 'K7QM-3XRP' : null }));

  route('POST', '/api/signup', null, async (c) => {
    if (!A.hit('signup:' + c.ip, 10, 3600000)) fail(429, 'rate_limited');
    const b = c.body;
    const role = A.oneOf(b.role, 'role', ['retailer', 'wholesaler']);
    const name = A.str(b.name, 'name', 2, 60), phone = phoneOf(b.phone);
    if (typeof b.password !== 'string' || b.password.length < 8 || b.password.length > 128) fail(400, 'weak_password');
    if (b.password.replace(/\D/g, '') === phone.replace(/\D/g, '')) fail(400, 'weak_password');
    const shopName = A.str(b.shop_name, 'shop_name', 2, 80), city = A.str(b.city, 'city', 2, 60);
    let gstin = null; // GSTIN is required for wholesalers only; retailers are never asked for it
    if (role === 'wholesaler') {
      if (!b.gstin) fail(400, 'gstin_required');
      const g = GST.validate(b.gstin); if (!g.ok) fail(400, 'invalid_gstin');
      gstin = g.gstin;
      if (q('SELECT 1 FROM shops WHERE gstin=? AND type=?').get(gstin, 'wholesaler')) fail(409, 'gstin_taken');
    }
    if (q('SELECT 1 FROM users WHERE phone=?').get(phone)) fail(409, 'phone_taken');
    const hash = await A.hashPassword(b.password);
    const user = tx(db, () => {
      if (q('SELECT 1 FROM users WHERE phone=?').get(phone)) fail(409, 'phone_taken');
      const uid = Number(q('INSERT INTO users(phone,name,role,pass_hash,created_at) VALUES(?,?,?,?,?)').run(phone, name, role, hash, now()).lastInsertRowid);
      const sid = Number(q('INSERT INTO shops(owner_id,type,name,city,gstin,verification,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(uid, role, shopName, city, gstin, role === 'retailer' ? 'approved' : 'pending', now()).lastInsertRowid);
      audit(db, { actorId: uid, actorLabel: name, action: 'signup', entity: 'shop', entityId: sid, detail: role + ' ' + shopName, ip: c.ip });
      return q('SELECT * FROM users WHERE id=?').get(uid);
    });
    startSession(c.res, user, c);
    return me(user);
  });

  route('POST', '/api/login', null, async (c) => {
    const phone = typeof c.body.phone === 'string' ? c.body.phone.replace(/[\s-]/g, '') : '';
    const pw = typeof c.body.password === 'string' ? c.body.password.slice(0, 128) : '';
    if (!A.hit('login-ip:' + c.ip, 20, 900000) || !A.hit('login-phone:' + phone, 6, 900000)) fail(429, 'rate_limited');
    const u = q('SELECT * FROM users WHERE phone=?').get(phone);
    const ok = await A.verifyPassword(pw, u ? u.pass_hash : A.DUMMY_HASH);
    if (!u || !ok || u.status !== 'active') {
      audit(db, { actorLabel: 'anonymous', action: 'login_failed', entity: 'user', entityId: u ? u.id : null, ip: c.ip });
      fail(401, 'invalid_credentials');
    }
    startSession(c.res, u, c);
    audit(db, { actorId: u.id, actorLabel: u.name, action: 'login', entity: 'user', entityId: u.id, ip: c.ip });
    return me(u);
  });

  route('POST', '/api/logout', 'any', (c) => {
    const m = /(?:^|;\s*)sl_sid=([A-Za-z0-9_-]{20,64})/.exec(c.req.headers.cookie || '');
    if (m) q('DELETE FROM sessions WHERE id=?').run(A.sha256(m[1]));
    c.res.setHeader('Set-Cookie', `sl_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${cfg.prod ? '; Secure' : ''}`);
    return { ok: true };
  });

  function me(u) {
    const shop = q('SELECT id,type,name,city,gstin,upi_id,verification,reject_reason FROM shops WHERE owner_id=?').get(u.id) || null;
    return { user: { id: u.id, name: u.name, phone: u.phone, role: u.role, lang: u.lang, tutorial_done: !!u.tutorial_done }, shop };
  }
  route('GET', '/api/me', 'any', (c) => me(c.user));
  route('POST', '/api/me/prefs', 'any', (c) => {
    if (c.body.lang !== undefined) q('UPDATE users SET lang=? WHERE id=?').run(A.oneOf(c.body.lang, 'lang', ['en', 'hi']), c.user.id);
    if (c.body.tutorial_done !== undefined) q('UPDATE users SET tutorial_done=? WHERE id=?').run(c.body.tutorial_done ? 1 : 0, c.user.id);
    return { ok: true };
  });

  /* ----- admin ----- */
  route('GET', '/api/admin/stats', 'admin', () => ({
    users: q('SELECT role,COUNT(*) n FROM users GROUP BY role').all(),
    shops: q('SELECT type,verification,COUNT(*) n FROM shops GROUP BY type,verification').all(),
    orders: q('SELECT status,COUNT(*) n, COALESCE(SUM(subtotal_paise),0) paise FROM orders GROUP BY status').all() }));
  route('GET', '/api/admin/shops', 'admin', (c) => {
    const st = c.query.get('status');
    const rows = q(`SELECT s.id,s.type,s.name,s.city,s.gstin,s.verification,s.reject_reason,s.created_at,u.name owner,u.phone,u.status user_status
      FROM shops s JOIN users u ON u.id=s.owner_id WHERE (?1 IS NULL OR s.verification=?1) ORDER BY s.id DESC LIMIT 200`).all(st || null);
    return { shops: rows.map(r => ({ ...r, gstin_state: GST.stateOf(r.gstin), gstin_valid: r.gstin ? GST.validate(r.gstin).ok : null })) };
  });
  route('POST', '/api/admin/shops/:id/verify', 'admin', (c) => {
    const act = A.oneOf(c.body.action, 'action', ['approve', 'reject', 'suspend', 'reinstate']);
    const reason = act === 'reject' || act === 'suspend' ? A.str(c.body.reason, 'reason', 3, 200) : null;
    const map = { approve: 'approved', reject: 'rejected', suspend: 'suspended', reinstate: 'approved' };
    const shop = tx(db, () => {
      const s = q('SELECT * FROM shops WHERE id=?').get(Number(c.params.id));
      if (!s) fail(404, 'not_found');
      q('UPDATE shops SET verification=?, reject_reason=? WHERE id=?').run(map[act], reason, s.id);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'shop_' + act, entity: 'shop', entityId: s.id, detail: s.name + (reason ? ' / ' + reason : ''), ip: c.ip });
      return s;
    });
    emit({ kind: 'catalog', wid: shop.id, scope: 'catalog', data: {} });
    return { ok: true, verification: map[act] };
  });
  route('GET', '/api/admin/audit', 'admin', (c) => {
    const limit = Math.min(200, Number(c.query.get('limit')) || 100), before = Number(c.query.get('before')) || 9e15;
    return { logs: q('SELECT id,ts,actor_user_id,actor_label,action,entity,entity_id,detail,ip FROM audit_logs WHERE id<? ORDER BY id DESC LIMIT ?').all(before, limit) };
  });
  route('GET', '/api/admin/audit/verify', 'admin', () => verifyAudit(db));
  route('POST', '/api/admin/reset-demo', 'admin', (c) => {
    if (!cfg.demo) fail(403, 'not_available');
    seed.resetDemo(db, cfg); return { ok: true };
  });

  /* ----- wholesaler ----- */
  const needApproved = (c) => { if (c.shop.verification !== 'approved') fail(403, 'shop_not_verified'); };
  route('GET', '/api/w/dashboard', 'wholesaler', (c) => {
    const sid = c.shop.id;
    const open = q(`SELECT COUNT(*) n FROM orders WHERE wholesaler_shop_id=? AND status NOT IN ('completed','cancelled','expired')`).get(sid).n;
    const pending = q(`SELECT COUNT(*) n FROM connections WHERE wholesaler_shop_id=? AND status='pending'`).get(sid).n;
    const low = q(`SELECT COUNT(*) n FROM products WHERE shop_id=? AND status!='archived' AND on_hand-reserved<=5`).get(sid).n;
    const reserved = q('SELECT COALESCE(SUM(reserved),0) n FROM products WHERE shop_id=?').get(sid).n;
    const sales = q(`SELECT COALESCE(SUM(subtotal_paise),0) n FROM orders WHERE wholesaler_shop_id=? AND status IN ('paid','packed','dispatched','completed')`).get(sid).n;
    return { open_orders: open, pending_requests: pending, low_stock: low, reserved_units: reserved, confirmed_value_paise: sales };
  });
  route('POST', '/api/w/profile', 'wholesaler', (c) => {
    const upi = A.str(c.body.upi_id, 'upi_id', 3, 80);
    if (!/^[a-zA-Z0-9._-]{2,64}@[a-zA-Z]{2,32}$/.test(upi)) fail(400, 'invalid_upi_id');
    q('UPDATE shops SET upi_id=? WHERE id=?').run(upi, c.shop.id);
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'set_upi_id', entity: 'shop', entityId: c.shop.id, ip: c.ip });
    return { ok: true };
  });
  route('GET', '/api/w/retailers', 'wholesaler', (c) => ({ connections: q(`
    SELECT c.id,c.status,c.source,c.credit_allowed,c.requested_at,c.decided_at,s.name,s.city,
      CASE WHEN c.status='approved' THEN u.phone END phone
    FROM connections c JOIN shops s ON s.id=c.retailer_shop_id JOIN users u ON u.id=s.owner_id
    WHERE c.wholesaler_shop_id=? ORDER BY CASE c.status WHEN 'pending' THEN 0 ELSE 1 END, c.requested_at DESC`).all(c.shop.id) }));
  route('POST', '/api/w/connections/:id', 'wholesaler', (c) => {
    const act = A.oneOf(c.body.action, 'action', ['approve', 'decline', 'revoke', 'block', 'credit']);
    const result = tx(db, () => {
      const cn = q('SELECT * FROM connections WHERE id=? AND wholesaler_shop_id=?').get(Number(c.params.id), c.shop.id);
      if (!cn) fail(404, 'not_found');
      const rs = q('SELECT name FROM shops WHERE id=?').get(cn.retailer_shop_id);
      let status = cn.status, detail = rs.name;
      if (act === 'approve') { needApproved(c); if (!['pending', 'revoked', 'rejected'].includes(cn.status)) fail(409, 'bad_state'); status = 'approved'; }
      else if (act === 'decline') { if (cn.status !== 'pending') fail(409, 'bad_state'); status = 'rejected'; }
      else if (act === 'revoke') { if (cn.status !== 'approved') fail(409, 'bad_state'); status = 'revoked'; }
      else if (act === 'block') status = 'blocked';
      if (act === 'credit') {
        const on = c.body.allowed ? 1 : 0; q('UPDATE connections SET credit_allowed=? WHERE id=?').run(on, cn.id); detail += ' credit=' + on;
      } else q('UPDATE connections SET status=?, decided_at=? WHERE id=?').run(status, now(), cn.id);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'connection_' + act, entity: 'connection', entityId: cn.id, detail, ip: c.ip });
      return cn;
    });
    emit({ kind: 'conn', wid: c.shop.id, rid: result.retailer_shop_id, data: {} });
    return { ok: true };
  });
  route('GET', '/api/w/invites', 'wholesaler', (c) => ({ invites: q('SELECT id,hint,max_uses,uses,expires_at,auto_approve,revoked_at,created_at FROM invite_codes WHERE shop_id=? ORDER BY id DESC LIMIT 20').all(c.shop.id)
    .map(i => ({ ...i, auto_approve: !!i.auto_approve, active: !i.revoked_at && i.expires_at > now() && i.uses < i.max_uses })) }));
  route('POST', '/api/w/invites', 'wholesaler', (c) => {
    needApproved(c);
    const max = c.body.max_uses === undefined ? 5 : A.int(c.body.max_uses, 'max_uses', 1, 100);
    const days = c.body.days === undefined ? 7 : A.int(c.body.days, 'days', 1, 30);
    const code = A.makeCode();
    tx(db, () => {
      if (q('SELECT COUNT(*) n FROM invite_codes WHERE shop_id=? AND revoked_at IS NULL AND expires_at>? AND uses<max_uses').get(c.shop.id, now()).n >= 10) fail(409, 'too_many_active_codes');
      const id = Number(q('INSERT INTO invite_codes(shop_id,code_hash,hint,max_uses,expires_at,auto_approve,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(c.shop.id, A.codeHash(code, secret), code.slice(-2), max, now() + days * DAY, c.body.auto_approve ? 1 : 0, now()).lastInsertRowid);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'invite_created', entity: 'invite', entityId: id, detail: 'hint ' + code.slice(-2) + ' max ' + max, ip: c.ip });
    });
    return { code: A.fmtCode(code) };
  });
  route('POST', '/api/w/invites/:id/revoke', 'wholesaler', (c) => {
    const r = q('UPDATE invite_codes SET revoked_at=? WHERE id=? AND shop_id=? AND revoked_at IS NULL').run(now(), Number(c.params.id), c.shop.id);
    if (r.changes !== 1) fail(404, 'not_found');
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'invite_revoked', entity: 'invite', entityId: c.params.id, ip: c.ip });
    return { ok: true };
  });

  const savePhotos = (pid, photos) => {
    photos.forEach((p, i) => q('INSERT INTO media(product_id,mime,data,sort,created_at) VALUES(?,?,?,?,?)').run(pid, p.mime, p.buf, i, now()));
  };
  const readPhotos = (arr, max) => {
    if (arr === undefined) return [];
    if (!Array.isArray(arr) || arr.length > max) fail(400, 'too_many_photos');
    return arr.map(x => A.parseImage(x, 600 * 1024));
  };
  route('GET', '/api/w/products', 'wholesaler', (c) => ({ products: q(`SELECT * FROM products WHERE shop_id=? AND status!='archived' ORDER BY id DESC`).all(c.shop.id).map(p => productOut(p, true)) }));
  route('POST', '/api/w/products', 'wholesaler', (c) => {
    const b = c.body;
    const name = A.str(b.name, 'name', 2, 100), spec = b.spec ? A.str(b.spec, 'spec', 0, 200) : '';
    const price = rupeesToPaise(b.price), stock = A.int(b.on_hand, 'on_hand', 0, 10000000);
    const unit = b.unit ? A.str(b.unit, 'unit', 1, 10) : 'pc', moq = b.moq === undefined ? 1 : A.int(b.moq, 'moq', 1, 100000);
    const photos = readPhotos(b.photos, 4);
    const id = tx(db, () => {
      const pid = Number(q('INSERT INTO products(shop_id,name,spec,price_paise,unit,moq,on_hand,is_new,stock_verified_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
        .run(c.shop.id, name, spec, price, unit, moq, stock, 1, now(), now()).lastInsertRowid);
      savePhotos(pid, photos);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'product_created', entity: 'product', entityId: pid, detail: name + ' stock ' + stock, ip: c.ip });
      return pid;
    });
    emit({ kind: 'catalog', wid: c.shop.id, scope: 'catalog', data: { product_id: id } });
    return { id };
  }, { big: true });
  const ownProduct = (c) => { const p = q('SELECT * FROM products WHERE id=? AND shop_id=?').get(Number(c.params.id), c.shop.id); if (!p) fail(404, 'not_found'); return p; };
  route('POST', '/api/w/products/:id/stock', 'wholesaler', (c) => {
    const p = tx(db, () => {
      const p = ownProduct(c);
      let next;
      if (c.body.set !== undefined) next = A.int(c.body.set, 'set', 0, 10000000);
      else { const d = c.body.delta; if (!Number.isInteger(d) || Math.abs(d) > 100000) fail(400, 'invalid_delta'); next = p.on_hand + d; }
      if (next < p.reserved) fail(409, 'below_reserved', { reserved: p.reserved });
      if (next > 10000000) fail(400, 'invalid_stock');
      q('UPDATE products SET on_hand=?, stock_verified_at=? WHERE id=?').run(next, now(), p.id);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'stock_adjusted', entity: 'product', entityId: p.id, detail: `${p.name}: ${p.on_hand} -> ${next}${c.body.reason ? ' (' + String(c.body.reason).slice(0, 40) + ')' : ''}`, ip: c.ip });
      return q('SELECT * FROM products WHERE id=?').get(p.id);
    });
    emit({ kind: 'stock', wid: c.shop.id, scope: 'catalog', data: { product_id: p.id, available: p.on_hand - p.reserved } });
    return productOut(p, true);
  });
  route('POST', '/api/w/products/:id/verify', 'wholesaler', (c) => {
    const p = ownProduct(c); q('UPDATE products SET stock_verified_at=? WHERE id=?').run(now(), p.id);
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'stock_verified', entity: 'product', entityId: p.id, detail: p.name, ip: c.ip });
    emit({ kind: 'stock', wid: c.shop.id, scope: 'catalog', data: { product_id: p.id, available: p.on_hand - p.reserved } });
    return { ok: true };
  });
  route('POST', '/api/w/products/:id/status', 'wholesaler', (c) => {
    const st = A.oneOf(c.body.status, 'status', ['active', 'paused', 'archived']); const p = ownProduct(c);
    q('UPDATE products SET status=? WHERE id=?').run(st, p.id);
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'product_' + st, entity: 'product', entityId: p.id, detail: p.name, ip: c.ip });
    emit({ kind: 'catalog', wid: c.shop.id, scope: 'catalog', data: { product_id: p.id } });
    return { ok: true };
  });
  route('POST', '/api/w/products/:id/update', 'wholesaler', (c) => {
    const p = ownProduct(c), b = c.body;
    const name = b.name !== undefined ? A.str(b.name, 'name', 2, 100) : p.name;
    const spec = b.spec !== undefined ? A.str(b.spec, 'spec', 0, 200) : p.spec;
    const price = b.price !== undefined ? rupeesToPaise(b.price) : p.price_paise;
    q('UPDATE products SET name=?,spec=?,price_paise=? WHERE id=?').run(name, spec, price, p.id);
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'product_updated', entity: 'product', entityId: p.id, detail: `price ${p.price_paise} -> ${price}`, ip: c.ip });
    emit({ kind: 'catalog', wid: c.shop.id, scope: 'catalog', data: { product_id: p.id } });
    return { ok: true };
  });
  route('POST', '/api/w/products/:id/photos', 'wholesaler', (c) => {
    const p = ownProduct(c);
    const have = q('SELECT COUNT(*) n FROM media WHERE product_id=?').get(p.id).n;
    const photos = readPhotos(c.body.photos, 4 - have < 0 ? 0 : 4 - have);
    if (!photos.length) fail(400, 'invalid_image');
    savePhotos(p.id, photos.map(x => x));
    audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'photos_added', entity: 'product', entityId: p.id, detail: String(photos.length), ip: c.ip });
    emit({ kind: 'catalog', wid: c.shop.id, scope: 'catalog', data: { product_id: p.id } });
    return { ok: true };
  }, { big: true });
  route('GET', '/api/w/orders', 'wholesaler', (c) => ({ orders: q('SELECT * FROM orders WHERE wholesaler_shop_id=? ORDER BY id DESC LIMIT 100').all(c.shop.id).map(o => orderOut(o, 'wholesaler')) }));

  const FLOW = ['received', 'paid', 'packed', 'dispatched', 'completed'];
  route('POST', '/api/w/orders/:id/advance', 'wholesaler', (c) => {
    const id = Number(c.params.id);
    const o = tx(db, () => {
      const o = q('SELECT * FROM orders WHERE id=? AND wholesaler_shop_id=?').get(id, c.shop.id);
      if (!o) fail(404, 'not_found');
      const i = FLOW.indexOf(o.status);
      if (i < 0 || i >= FLOW.length - 1) fail(409, 'bad_state');
      const next = FLOW[i + 1];
      if (next === 'paid' && o.payment_mode === 'upi' && !o.utr) fail(409, 'payment_reference_missing');
      if (next === 'dispatched') {
        for (const it of q('SELECT product_id,qty FROM order_items WHERE order_id=?').all(o.id)) {
          const r = q('UPDATE products SET on_hand=on_hand-?, reserved=reserved-? WHERE id=? AND reserved>=? AND on_hand>=?').run(it.qty, it.qty, it.product_id, it.qty, it.qty);
          if (r.changes !== 1) fail(409, 'stock_mismatch');
        }
      }
      if (next === 'completed' && o.fulfilment === 'pickup' && !A.safeEqual(String(c.body.pickup_code || '').toUpperCase(), o.pickup_code)) fail(403, 'wrong_pickup_code');
      setStatus(o, next, c.user.id, null);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'order_' + next, entity: 'order', entityId: o.id, detail: o.no, ip: c.ip });
      return q('SELECT * FROM orders WHERE id=?').get(o.id);
    });
    emitStockFor(o.id); emit({ kind: 'order', wid: o.wholesaler_shop_id, rid: o.retailer_shop_id, data: { order_id: o.id, status: o.status } });
    return orderOut(o, 'wholesaler');
  });
  const cancelOrder = (c, o, who, reason) => {
    const r = tx(db, () => {
      const cur = q('SELECT * FROM orders WHERE id=?').get(o.id);
      const allowed = who === 'wholesaler' ? ['received', 'paid', 'packed'] : ['received'];
      if (!allowed.includes(cur.status)) fail(409, 'bad_state');
      releaseItems(cur.id);
      q('UPDATE orders SET cancel_reason=? WHERE id=?').run(reason, cur.id);
      setStatus(cur, 'cancelled', c.user.id, reason);
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'order_cancelled', entity: 'order', entityId: cur.id, detail: cur.no + ' by ' + who + ': ' + reason, ip: c.ip });
      return q('SELECT * FROM orders WHERE id=?').get(cur.id);
    });
    emitStockFor(r.id); emit({ kind: 'order', wid: r.wholesaler_shop_id, rid: r.retailer_shop_id, data: { order_id: r.id, status: r.status } });
    return r;
  };
  route('POST', '/api/w/orders/:id/cancel', 'wholesaler', (c) => {
    const o = q('SELECT * FROM orders WHERE id=? AND wholesaler_shop_id=?').get(Number(c.params.id), c.shop.id); if (!o) fail(404, 'not_found');
    return orderOut(cancelOrder(c, o, 'wholesaler', A.str(c.body.reason || 'Cancelled by wholesaler', 'reason', 3, 200)), 'wholesaler');
  });

  /* ----- retailer ----- */
  route('GET', '/api/shops/search', 'retailer', (c) => {
    const term = String(c.query.get('q') || '').trim().slice(0, 40).replace(/[\\%_]/g, m => '\\' + m);
    if (term.length < 2) return { shops: [] };
    const like = '%' + term + '%';
    return { shops: q(`SELECT s.id,s.name,s.city,(SELECT status FROM connections WHERE wholesaler_shop_id=s.id AND retailer_shop_id=?) conn
      FROM shops s JOIN users u ON u.id=s.owner_id WHERE s.type='wholesaler' AND s.verification='approved' AND u.status='active'
      AND (s.name LIKE ? ESCAPE '\\' OR s.city LIKE ? ESCAPE '\\') ORDER BY s.name LIMIT 20`).all(c.shop.id, like, like) };
  });
  route('GET', '/api/r/wholesalers', 'retailer', (c) => ({ connections: q(`
    SELECT c.id,c.status,c.credit_allowed,s.id shop_id,s.name,s.city,s.verification,
      CASE WHEN c.status='approved' THEN s.upi_id END upi_id
    FROM connections c JOIN shops s ON s.id=c.wholesaler_shop_id WHERE c.retailer_shop_id=? ORDER BY c.requested_at DESC`).all(c.shop.id) }));
  route('POST', '/api/r/join', 'retailer', (c) => {
    const uid = c.user.id, since = now() - 3600000;
    const failsUser = q('SELECT COUNT(*) n FROM code_attempts WHERE user_id=? AND ok=0 AND ts>?').get(uid, since).n;
    const failsIp = q('SELECT COUNT(*) n FROM code_attempts WHERE ip=? AND ok=0 AND ts>?').get(c.ip, since).n;
    if (failsUser >= 5 || failsIp >= 20) fail(429, 'too_many_attempts');
    const code = typeof c.body.code === 'string' ? c.body.code.slice(0, 20) : '';
    const bad = () => {
      q('INSERT INTO code_attempts(user_id,ip,ok,ts) VALUES(?,?,0,?)').run(uid, c.ip, now());
      audit(db, { actorId: uid, actorLabel: c.user.name, action: 'invite_failed', entity: 'invite', ip: c.ip });
      fail(400, 'invalid_code');
    };
    if (A.normCode(code).length !== 8) bad();
    const out = tx(db, () => {
      const inv = q(`SELECT i.*, s.verification FROM invite_codes i JOIN shops s ON s.id=i.shop_id WHERE i.code_hash=?`).get(A.codeHash(code, secret));
      if (!inv || inv.revoked_at || inv.expires_at <= now() || inv.uses >= inv.max_uses || inv.verification !== 'approved') return null;
      const cn = q('SELECT * FROM connections WHERE wholesaler_shop_id=? AND retailer_shop_id=?').get(inv.shop_id, c.shop.id);
      if (cn && cn.status === 'blocked') return null;
      if (cn && cn.status === 'approved') return { already: true, wid: inv.shop_id };
      const status = inv.auto_approve ? 'approved' : 'pending';
      q('UPDATE invite_codes SET uses=uses+1 WHERE id=?').run(inv.id);
      if (cn) q('UPDATE connections SET status=?, source=?, invite_code_id=?, requested_at=?, decided_at=? WHERE id=?').run(status, 'invite_code', inv.id, now(), inv.auto_approve ? now() : null, cn.id);
      else q('INSERT INTO connections(wholesaler_shop_id,retailer_shop_id,status,source,invite_code_id,requested_at,decided_at) VALUES(?,?,?,?,?,?,?)').run(inv.shop_id, c.shop.id, status, 'invite_code', inv.id, now(), inv.auto_approve ? now() : null);
      audit(db, { actorId: uid, actorLabel: c.user.name, action: 'joined_with_invite', entity: 'shop', entityId: inv.shop_id, detail: 'status ' + status + ', hint ' + inv.hint, ip: c.ip });
      q('INSERT INTO code_attempts(user_id,ip,ok,ts) VALUES(?,?,1,?)').run(uid, c.ip, now());
      return { status, wid: inv.shop_id };
    });
    if (!out) bad();
    if (out.already) fail(409, 'already_connected');
    emit({ kind: 'conn', wid: out.wid, rid: c.shop.id, data: {} });
    return { status: out.status };
  });
  route('POST', '/api/r/request', 'retailer', (c) => {
    if (!A.hit('request:' + c.user.id, 10, 3600000)) fail(429, 'rate_limited');
    const wid = A.int(c.body.wholesaler_shop_id, 'wholesaler_shop_id', 1, 1e9);
    const w = q(`SELECT s.id FROM shops s JOIN users u ON u.id=s.owner_id WHERE s.id=? AND s.type='wholesaler' AND s.verification='approved' AND u.status='active'`).get(wid);
    if (!w) fail(404, 'not_found');
    tx(db, () => {
      const cn = q('SELECT * FROM connections WHERE wholesaler_shop_id=? AND retailer_shop_id=?').get(wid, c.shop.id);
      if (cn && cn.status === 'blocked') fail(403, 'cannot_request');
      if (cn && cn.status === 'approved') fail(409, 'already_connected');
      if (cn && cn.status === 'pending') return;
      if (cn) q(`UPDATE connections SET status='pending', source='request', requested_at=?, decided_at=NULL WHERE id=?`).run(now(), cn.id);
      else q(`INSERT INTO connections(wholesaler_shop_id,retailer_shop_id,status,source,requested_at) VALUES(?,?,'pending','request',?)`).run(wid, c.shop.id, now());
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'access_requested', entity: 'shop', entityId: wid, ip: c.ip });
    });
    emit({ kind: 'conn', wid, rid: c.shop.id, data: {} });
    return { status: 'pending' };
  });
  route('GET', '/api/r/catalog/:id', 'retailer', (c) => {
    const wid = Number(c.params.id);
    if (!connApproved(wid, c.shop.id)) fail(403, 'not_connected');
    const shop = q('SELECT id,name,city,upi_id FROM shops WHERE id=?').get(wid);
    return { shop, products: q(`SELECT * FROM products WHERE shop_id=? AND status IN ('active','paused') ORDER BY is_new DESC, id DESC`).all(wid).map(p => productOut(p, false)) };
  });
  route('POST', '/api/r/orders', 'retailer', (c) => {
    if (!A.hit('order:' + c.user.id, 30, 60000)) fail(429, 'rate_limited');
    const b = c.body;
    const wid = A.int(b.shop_id, 'shop_id', 1, 1e9);
    if (!Array.isArray(b.items) || b.items.length < 1 || b.items.length > 20) fail(400, 'invalid_items');
    const seen = new Set();
    const items = b.items.map(x => {
      if (!x || typeof x !== 'object') fail(400, 'invalid_items');
      const pid = A.int(x.product_id, 'product_id', 1, 1e9), qty = A.int(x.qty, 'qty', 1, 100000);
      if (seen.has(pid)) fail(400, 'duplicate_item'); seen.add(pid); return { pid, qty };
    });
    const fulfilment = A.oneOf(b.fulfilment, 'fulfilment', ['pickup', 'home']);
    const address = fulfilment === 'home' ? A.str(b.address, 'address', 5, 300) : null;
    const mode = A.oneOf(b.payment_mode, 'payment_mode', ['upi', 'credit', 'cod']);
    const idem = A.str(b.idem_key, 'idem_key', 8, 64);
    const result = tx(db, () => {
      const dup = q('SELECT * FROM orders WHERE retailer_shop_id=? AND idem_key=?').get(c.shop.id, idem);
      if (dup) return { order: dup, dup: true };
      const cn = q(`SELECT c.credit_allowed FROM connections c JOIN shops w ON w.id=c.wholesaler_shop_id JOIN users u ON u.id=w.owner_id
        WHERE c.wholesaler_shop_id=? AND c.retailer_shop_id=? AND c.status='approved' AND w.verification='approved' AND u.status='active'`).get(wid, c.shop.id);
      if (!cn) fail(403, 'not_connected');
      if (mode === 'credit' && !cn.credit_allowed) fail(403, 'credit_not_allowed');
      if (q(`SELECT COUNT(*) n FROM orders WHERE retailer_shop_id=? AND wholesaler_shop_id=? AND status='received'`).get(c.shop.id, wid).n >= 5) fail(429, 'too_many_open_orders');
      let subtotal = 0; const lines = [];
      for (const it of items) {
        const p = q(`SELECT * FROM products WHERE id=? AND shop_id=? AND status='active'`).get(it.pid, wid);
        if (!p) fail(404, 'product_unavailable', { product_id: it.pid });
        if (it.qty < p.moq) fail(400, 'below_moq', { product_id: it.pid, moq: p.moq });
        const r = q(`UPDATE products SET reserved=reserved+? WHERE id=? AND shop_id=? AND status='active' AND on_hand-reserved>=?`).run(it.qty, it.pid, wid, it.qty);
        if (r.changes !== 1) fail(409, 'insufficient_stock', { product_id: it.pid, available: Math.max(0, p.on_hand - p.reserved) });
        subtotal += p.price_paise * it.qty; lines.push({ p, qty: it.qty });
      }
      const oid = Number(q('INSERT INTO orders(no,wholesaler_shop_id,retailer_shop_id,placed_by,status,fulfilment,address,pickup_code,payment_mode,subtotal_paise,idem_key,reserve_expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run('PENDING', wid, c.shop.id, c.user.id, 'received', fulfilment, address, A.makeCode().slice(0, 6), mode, subtotal, idem, mode === 'credit' ? null : now() + DAY, now(), now()).lastInsertRowid);
      const no = 'SL-' + String(1000 + oid);
      q('UPDATE orders SET no=? WHERE id=?').run(no, oid);
      for (const l of lines) q('INSERT INTO order_items(order_id,product_id,name_snapshot,unit_price_paise,qty) VALUES(?,?,?,?,?)').run(oid, l.p.id, l.p.name, l.p.price_paise, l.qty);
      q('INSERT INTO order_history(order_id,status,actor_user_id,note,ts) VALUES(?,?,?,?,?)').run(oid, 'received', c.user.id, null, now());
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'order_placed', entity: 'order', entityId: oid, detail: `${no} total ${subtotal} items ${lines.length}`, ip: c.ip });
      return { order: q('SELECT * FROM orders WHERE id=?').get(oid) };
    });
    if (!result.dup) { emitStockFor(result.order.id); emit({ kind: 'order', wid, rid: c.shop.id, data: { order_id: result.order.id, status: 'received' } }); }
    return { ...orderOut(result.order, 'retailer'), duplicate: !!result.dup };
  });
  route('GET', '/api/r/orders', 'retailer', (c) => ({ orders: q('SELECT * FROM orders WHERE retailer_shop_id=? ORDER BY id DESC LIMIT 100').all(c.shop.id).map(o => orderOut(o, 'retailer')) }));
  route('POST', '/api/r/orders/:id/cancel', 'retailer', (c) => {
    const o = q('SELECT * FROM orders WHERE id=? AND retailer_shop_id=?').get(Number(c.params.id), c.shop.id); if (!o) fail(404, 'not_found');
    return orderOut(cancelOrder(c, o, 'retailer', A.str(c.body.reason || 'Cancelled by retailer', 'reason', 3, 200)), 'retailer');
  });
  route('POST', '/api/r/orders/:id/payment', 'retailer', (c) => {
    const utr = A.str(c.body.utr, 'utr', 6, 30).toUpperCase();
    if (!/^[A-Z0-9]+$/.test(utr)) fail(400, 'invalid_utr');
    const proof = c.body.proof ? A.parseImage(c.body.proof, 800 * 1024) : null;
    const o = tx(db, () => {
      const cur = q('SELECT * FROM orders WHERE id=? AND retailer_shop_id=?').get(Number(c.params.id), c.shop.id);
      if (!cur) fail(404, 'not_found');
      if (cur.payment_mode !== 'upi' || cur.status !== 'received') fail(409, 'bad_state');
      try { q('UPDATE orders SET utr=?, proof_mime=?, proof_data=?, updated_at=? WHERE id=?').run(utr, proof ? proof.mime : null, proof ? proof.buf : null, now(), cur.id); }
      catch (e) { if (/UNIQUE/i.test(String(e.message))) fail(409, 'utr_already_used'); throw e; }
      audit(db, { actorId: c.user.id, actorLabel: c.user.name, action: 'payment_reference_submitted', entity: 'order', entityId: cur.id, detail: cur.no, ip: c.ip });
      return q('SELECT * FROM orders WHERE id=?').get(cur.id);
    });
    emit({ kind: 'order', wid: o.wholesaler_shop_id, rid: o.retailer_shop_id, data: { order_id: o.id, status: o.status } });
    return orderOut(o, 'retailer');
  }, { big: true });

  /* ----- shared ----- */
  route('GET', '/api/media/:id', 'any', (c) => {
    const m = q('SELECT m.mime,m.data,p.shop_id,p.status FROM media m JOIN products p ON p.id=m.product_id WHERE m.id=?').get(Number(c.params.id));
    let ok = false;
    if (m) {
      if (c.user.role === 'admin') ok = true;
      else if (c.shop && c.shop.id === m.shop_id) ok = true;
      else if (c.user.role === 'retailer' && m.status !== 'archived' && connApproved(m.shop_id, c.shop.id)) ok = true;
    }
    if (!ok) fail(404, 'not_found');
    return { raw: Buffer.from(m.data), mime: m.mime };
  });
  route('GET', '/api/orders/:id/proof', 'any', (c) => {
    const o = q('SELECT * FROM orders WHERE id=?').get(Number(c.params.id));
    let ok = false;
    if (o && o.proof_data) ok = c.user.role === 'admin' || (c.shop && (c.shop.id === o.wholesaler_shop_id || c.shop.id === o.retailer_shop_id));
    if (!ok) fail(404, 'not_found');
    return { raw: Buffer.from(o.proof_data), mime: o.proof_mime };
  });
  route('GET', '/api/stream', 'any', (c) => {
    const mine = [...clients].filter(x => x.userId === c.user.id).length;
    if (mine >= 5) fail(429, 'too_many_streams');
    c.res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no', ...baseHeaders() });
    c.res.write('retry: 4000\nevent: hello\ndata: {}\n\n');
    const cl = { res: c.res, userId: c.user.id, role: c.user.role, shopId: c.shop ? c.shop.id : null };
    clients.add(cl);
    const hb = setInterval(() => { try { c.res.write(': hb\n\n'); } catch (_) {} }, 25000);
    c.req.on('close', () => { clearInterval(hb); clients.delete(cl); });
    return { streaming: true };
  });

  /* ---------- reservation expiry ---------- */
  function expireOrders() {
    const rows = q(`SELECT id FROM orders WHERE status='received' AND reserve_expires_at IS NOT NULL AND reserve_expires_at<?`).all(now());
    for (const r of rows) {
      let o;
      try {
        o = tx(db, () => {
          const cur = q('SELECT * FROM orders WHERE id=?').get(r.id);
          if (cur.status !== 'received') return null;
          releaseItems(cur.id); setStatus(cur, 'expired', null, 'Reservation expired');
          audit(db, { actorLabel: 'system', action: 'order_expired', entity: 'order', entityId: cur.id, detail: cur.no });
          return cur;
        });
      } catch (e) { console.error('expire failed', e.message); }
      if (o) { emitStockFor(o.id); emit({ kind: 'order', wid: o.wholesaler_shop_id, rid: o.retailer_shop_id, data: { order_id: o.id, status: 'expired' } }); }
    }
    return rows.length;
  }
  const expTimer = setInterval(expireOrders, 60000); expTimer.unref();

  /* ---------- http plumbing ---------- */
  function baseHeaders() {
    const h = {
      'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; manifest-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
      'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
      'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Resource-Policy': 'same-origin',
      'Permissions-Policy': 'camera=(self), microphone=(), geolocation=(), payment=()'
    };
    if (cfg.prod) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
    return h;
  }
  function clientIp(req) {
    if (cfg.trustProxy) { const x = String(req.headers['x-forwarded-for'] || '').split(',').map(s => s.trim()).filter(Boolean); if (x.length) return x[x.length - 1].slice(0, 64); }
    return req.socket.remoteAddress || 'unknown';
  }
  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      let size = 0, over = false; const chunks = [];
      req.on('data', (d) => { size += d.length; if (size > limit) { if (!over) { over = true; reject(new HttpError(413, 'body_too_large')); } return; } if (!over) chunks.push(d); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  function send(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...baseHeaders(), ...(extra || {}) });
    res.end(body);
  }

  const server = http.createServer(async (req, res) => {
    const ip = clientIp(req);
    let url;
    try { url = new URL(req.url, 'http://x'); } catch (_) { res.writeHead(400); return res.end(); }
    const p = url.pathname;
    try {
      if (!p.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') fail(405, 'method_not_allowed');
        const file = STATIC[p];
        if (!file || !staticCache[file]) { res.writeHead(404, { 'Content-Type': 'text/plain', ...baseHeaders() }); return res.end('Not found'); }
        const ext = file.split('.').pop();
        res.writeHead(200, { 'Content-Type': TYPES[ext], 'Cache-Control': 'no-cache', ...baseHeaders() });
        return res.end(req.method === 'HEAD' ? undefined : staticCache[file]);
      }
      if (!A.hit('ip:' + ip, 900, 60000)) fail(429, 'rate_limited');
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        if (req.headers['x-requested-with'] !== 'StockLink') fail(403, 'csrf');
        const origin = req.headers.origin;
        if (origin) { let h = null; try { h = new URL(origin).host; } catch (_) {} if (h !== req.headers.host) fail(403, 'csrf'); }
      }
      let matched = null, params = {};
      for (const r of R) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(p); if (!m) continue;
        matched = r; r.keys.forEach((k, i) => { params[k] = m[i + 1]; }); break;
      }
      if (!matched) fail(404, 'not_found');
      let user = null, shop = null;
      if (matched.auth) {
        user = sessionUser(req);
        if (!user) fail(401, 'not_authenticated');
        if (matched.auth !== 'any' && user.role !== matched.auth) fail(403, 'forbidden');
        shop = q('SELECT * FROM shops WHERE owner_id=?').get(user.id) || null;
        if (matched.auth !== 'admin' && matched.auth !== 'any' && !shop) fail(403, 'forbidden');
      }
      let body = {};
      if (req.method === 'POST') {
        const raw = await readBody(req, matched.big ? 3 * 1024 * 1024 : 32 * 1024);
        if (raw.length) {
          if (!/^application\/json/i.test(req.headers['content-type'] || '')) fail(415, 'json_required');
          try { body = JSON.parse(raw.toString('utf8')); } catch (_) { fail(400, 'invalid_json'); }
          if (body === null || typeof body !== 'object' || Array.isArray(body)) fail(400, 'invalid_json');
        }
      }
      const out = await matched.handler({ req, res, params, body, user, shop, ip, query: url.searchParams });
      if (out && out.streaming) return;
      if (out && out.raw) {
        res.writeHead(200, { 'Content-Type': out.mime, 'Cache-Control': 'private, max-age=60', 'Content-Security-Policy': "default-src 'none'; sandbox", 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline', 'Cross-Origin-Resource-Policy': 'same-origin' });
        return res.end(out.raw);
      }
      send(res, 200, out === undefined ? { ok: true } : out);
    } catch (e) {
      if (e instanceof HttpError) {
        if (!res.headersSent) send(res, e.status, { error: e.code, ...e.extra }, e.status === 413 ? { Connection: 'close' } : undefined);
        if (e.status === 413) res.once('finish', () => req.destroy());
        return;
      }
      console.error('server_error', req.method, p, e && e.message);
      if (!res.headersSent) send(res, 500, { error: 'server_error' });
    }
  });
  server.headersTimeout = 15000; server.requestTimeout = 30000; server.keepAliveTimeout = 5000;
  return { server, db, expireOrders, cfg, close: () => { clearInterval(expTimer); for (const c of clients) { try { c.res.end(); } catch (_) {} } return new Promise(r => server.close(r)); } };
}

if (require.main === module) {
  const cfg = loadConfig();
  const app = createApp(cfg);
  app.server.listen(cfg.port, cfg.host, () => console.log(`StockLink running on http://localhost:${cfg.port}${cfg.demo ? '  (DEMO MODE: sample data and public demo logins)' : ''}`));
  for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => app.close().then(() => process.exit(0)));
}
module.exports = { createApp, loadConfig };
