const { chromium } = require('playwright');
const base = process.env.BASE || 'http://localhost:3111';
(async () => {
  const b = await chromium.launch(); const errs = [];
  const mk = async () => { const ctx = await b.newContext({ viewport: { width: 400, height: 800 } }); const p = await ctx.newPage();
    p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); return p; };
  const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
  const login = async (p, phone) => { await p.goto(base); await p.click('[data-act=fill][data-id="' + phone + '"]'); await p.click('form button[type=submit]'); await p.waitForSelector('.nav'); };
  const skipTut = async (p) => { if (await p.$('[data-act=tutskip]')) await p.click('[data-act=tutskip]'); await p.waitForSelector('.modal', { state: 'detached' }); };
  // wholesaler
  const w = await mk(); await login(w, '9000000002'); ok(!!(await w.$('.modal')), 'wholesaler tutorial shows on first login'); await skipTut(w);
  // retailer not connected
  const r = await mk(); await login(r, '9000000006'); await skipTut(r);
  ok((await r.textContent('.screen')).includes('Catalog locked'), 'unconnected retailer sees locked catalog');
  await r.fill('#code', 'k7qm-3xrp'); await r.click('[data-act=join]'); await r.waitForSelector('.banner.info');
  ok(true, 'retailer joined via code (pending)');
  // wholesaler approves (live)
  await w.click('[data-act=tab][data-id=retailers]'); await w.waitForSelector('[data-act=conn][data-id$=":approve"]');
  const approves = await w.$$('[data-act=conn][data-id$=":approve"]'); ok(approves.length >= 2, 'wholesaler sees pending requests: ' + approves.length);
  const card = await w.$('.card:has-text("Kulkarni Machinery")'); await (await card.$('[data-act=conn]')).click();
  await r.waitForSelector('.prod', { timeout: 8000 }); ok(true, 'retailer catalog unlocked live via SSE after approval');
  // order
  await r.click('[data-act=cart][data-id$=":1"]'); await r.click('[data-act=cart][data-id$=":1"]'); await r.click('[data-act=review]');
  await r.click('[data-act=place]'); await r.waitForSelector('text=Order SL-', { timeout: 5000 }).catch(() => {});
  await r.click('[data-act=tab][data-id=orders]'); await r.waitForSelector('.track');
  const txt = await r.textContent('.screen'); ok(/SL-10\d\d/.test(txt) && txt.includes('Pickup code'), 'order placed with pickup code');
  // pay UPI
  await r.fill('[id^=utr_]', 'UTR998877665544'); await r.click('[data-act=paysubmit]'); await r.waitForSelector('text=UTR998877665544');
  ok(true, 'UTR submitted');
  await w.click('[data-act=tab][data-id=orders]'); await w.waitForSelector('[data-act=adv]');
  for (const label of ['Payment verified', 'Mark packed', 'Dispatch', 'Ready for pickup']) { const btn = await w.$('[data-act=adv]:has-text("' + label + '")'); if (btn) { await btn.click(); await w.waitForTimeout(500); } }
  const code = (await r.textContent('.pick')).trim();
  await r.waitForTimeout(800); ok(code.length === 6, 'pickup code is 6 chars');
  const cnt=async()=> (await w.$$('.badge.good:has-text("Completed")')).length; const c0=await cnt(); await w.fill('[id^=pc_]', 'WRONG1'); await w.click('[data-act=adv]'); await w.waitForTimeout(500);
  ok((await cnt())===c0, 'wrong pickup code rejected');
  await w.fill('[id^=pc_]', code); await w.click('[data-act=adv]'); await w.waitForTimeout(700);
  ok((await cnt())===c0+1, 'order completed with correct pickup code');
  // hinglish toggle
  await r.click('[data-act=lang][data-id=hi]'); ok((await r.textContent('.nav')).includes('Catalog'), 'language toggles');
  // XSS check: product name
  const w2 = w; await w2.click('[data-act=tab][data-id=stock]'); await w2.fill('#pname', '<img src=x onerror=window.__x=1>'); await w2.fill('#pprice', '10'); await w2.fill('#pstock', '3'); await w2.click('[data-act=addp]'); await w2.waitForTimeout(800);
  ok(!(await w2.evaluate(() => window.__x)), 'XSS payload not executed');
  ok((await w2.textContent('.screen')).includes('<img src=x'), 'payload rendered as text');
  // admin
  const a = await mk(); await login(a, '9000000001'); await skipTut(a); ok((await a.textContent('.screen')).includes('Patel'), 'admin sees pending shop');
  await a.click('[data-act=tab][data-id=audit]'); await a.click('[data-act=verifychain]'); await a.waitForSelector('.banner'); ok((await a.textContent('.banner')).includes('intact'), 'audit chain verified in UI');
  await w.screenshot({ path: '/tmp/sl_e2e/w.png' }); await r.screenshot({ path: '/tmp/sl_e2e/r.png' });
  console.log('console errors:', errs.filter(e => !/Failed to load resource/.test(e)));
  await b.close();
})().catch(e => { console.error('E2E CRASH', e.message); process.exit(1); });
