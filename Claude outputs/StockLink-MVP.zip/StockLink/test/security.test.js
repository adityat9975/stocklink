'use strict';
// Run: npm test   (starts its own server on a temp DB, no network needed)
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sl-sec-'));
const { createApp, loadConfig } = require('../server');
const A = require('../lib/auth');
const { verifyAudit } = require('../lib/db');
const cfg = loadConfig({ DB_PATH: path.join(dir, 't.db'), DEMO_MODE: '1', PORT: '0', HOST: '127.0.0.1', SESSION_SECRET: 'test-secret-' + 'x'.repeat(32) });
const PW = 'Demo@1234', PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
let pass = 0, fail = 0; const failures = [];
const ok = (c, m) => { if (c) { pass++; console.log('  PASS ' + m); } else { fail++; failures.push(m); console.log('  FAIL ' + m); } };
let base;
async function call(method, url, { body, jar, headers, raw, noCsrf } = {}) {
  const h = { ...(noCsrf ? {} : { 'X-Requested-With': 'StockLink' }), ...(headers || {}) };
  if (jar && jar.c) h.Cookie = jar.c;
  if (body !== undefined && !raw) { h['Content-Type'] = 'application/json'; }
  const r = await fetch(base + url, { method, headers: h, body: body === undefined ? undefined : raw ? body : JSON.stringify(body), redirect: 'manual' });
  const sc = r.headers.get('set-cookie'); if (jar && sc) jar.c = sc.split(';')[0];
  let j = null; const ct = r.headers.get('content-type') || ''; if (ct.includes('json')) { try { j = await r.json(); } catch (_) {} } else await r.arrayBuffer();
  return { s: r.status, j, h: r.headers, sc };
}
async function login(phone, pw = PW) { A.resetLimits(); const jar = {}; const r = await call('POST', '/api/login', { body: { phone, password: pw }, jar }); if (r.s !== 200) throw new Error('login ' + phone + ' ' + r.s); return jar; }
const sec = (n) => console.log('\n' + n);

(async () => {
  const app = createApp(cfg); await new Promise(r => app.server.listen(0, '127.0.0.1', r)); base = 'http://127.0.0.1:' + app.server.address().port;
  const seed = require('../seed'); seed.seedDemoIfEmpty(app.db, cfg);
  const db2 = new DatabaseSync(cfg.dbPath);
  const sharma = await login('9000000002'), rahul = await login('9000000004'), kul = await login('9000000006'), verma = await login('9000000005'), admin = await login('9000000001'), patel = await login('9000000003');
  const WID = app.db.prepare("SELECT id FROM shops WHERE name='Sharma Traders'").get().id;
  const prodRow = (n) => app.db.prepare('SELECT * FROM products WHERE name LIKE ?').get(n + '%');

  sec('1. Authentication & sessions');
  ok((await call('GET', '/api/me')).s === 401, 'unauthenticated /api/me -> 401');
  for (const u of ['/api/w/orders', '/api/r/orders', '/api/admin/stats', '/api/media/1', '/api/stream']) ok((await call('GET', u)).s === 401, 'unauthenticated ' + u + ' -> 401');
  A.resetLimits(); ok((await call('POST', '/api/login', { body: { phone: '9000000002', password: 'wrong' } })).s === 401, 'wrong password -> 401');
  const unknown = await call('POST', '/api/login', { body: { phone: '9111111111', password: 'whatever12' } });
  const known = await call('POST', '/api/login', { body: { phone: '9000000002', password: 'wrong-pass' } });
  ok(unknown.s === known.s && unknown.j.error === known.j.error, 'unknown user and wrong password give identical responses (no user enumeration)');
  const cj = {}; A.resetLimits(); const lr = await call('POST', '/api/login', { body: { phone: '9000000002', password: PW }, jar: cj });
  ok(/HttpOnly/i.test(lr.sc) && /SameSite=Lax/i.test(lr.sc), 'session cookie is HttpOnly + SameSite=Lax');
  const tok = cj.c.split('=')[1]; const stored = app.db.prepare('SELECT id FROM sessions').all().map(r => r.id);
  ok(!stored.includes(tok) && stored.includes(A.sha256(tok)), 'only SHA-256 of session token is stored');
  const hashes = app.db.prepare('SELECT pass_hash FROM users').all(); ok(hashes.every(h => h.pass_hash.startsWith('scrypt$') || h.pass_hash.includes('$')) && !hashes.some(h => h.pass_hash.includes(PW)), 'passwords stored as salted scrypt hashes');
  A.resetLimits(); let limited = 0; for (let i = 0; i < 9; i++) { const r = await call('POST', '/api/login', { body: { phone: '9000000006', password: 'bad' + i } }); if (r.s === 429) limited++; }
  ok(limited >= 3, 'login brute force is rate limited (' + limited + ' of 9 blocked)');
  A.resetLimits();
  const out = await login('9000000006'); await call('POST', '/api/logout', { jar: out, body: {} }); ok((await call('GET', '/api/me', { jar: out })).s === 401, 'logout invalidates the session server-side');
  app.db.prepare('UPDATE sessions SET expires_at=1 WHERE user_id=(SELECT id FROM users WHERE phone=?)').run('9000000005'); ok((await call('GET', '/api/me', { jar: verma })).s === 401, 'expired session rejected');
  const verma2 = await login('9000000005');
  ok((await call('GET', '/api/me', { jar: { c: 'sl_sid=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA' } })).s === 401, 'forged session cookie rejected');
  A.resetLimits(); const su = await call('POST', '/api/signup', { body: { role: 'admin', name: 'Evil', phone: '9333333331', password: 'Passw0rd!x', shop_name: 'X Shop', city: 'Pune' } });
  ok(su.s === 400, 'cannot sign up as admin (role escalation)');
  const su2 = await call('POST', '/api/signup', { body: { role: 'wholesaler', name: 'New W', phone: '9333333332', password: 'Passw0rd!x', shop_name: 'New Whole', city: 'Pune', gstin: '27AAPFU0939F1ZV', verification: 'approved', status: 'active', is_admin: 1 } });
  ok(su2.s === 200 && app.db.prepare("SELECT s.verification v FROM shops s JOIN users u ON u.id=s.owner_id WHERE u.phone='9333333332'").get().v === 'pending', 'mass assignment ignored: new wholesaler stays pending verification');
  const sg = (o) => call('POST', '/api/signup', { body: { role: 'wholesaler', name: 'G Test', phone: '9444' + String(Math.floor(Math.random() * 1e6)).padStart(6, '0'), password: 'Passw0rd!x', shop_name: 'G Shop', city: 'Pune', ...o } });
  ok((await sg({})).s === 400, 'wholesaler signup without GSTIN rejected');
  ok((await sg({ gstin: '27AAPFU0939F1ZX' })).s === 400, 'GSTIN with wrong check digit rejected');
  ok((await sg({ gstin: 'NOTAGSTIN123456' })).s === 400, 'malformed GSTIN rejected');
  ok((await sg({ gstin: '27AAPFU0939F1ZV' })).s === 409, 'same GSTIN cannot be registered twice');
  ok((await call('POST', '/api/signup', { body: { role: 'retailer', name: 'No Gst', phone: '9555000001', password: 'Passw0rd!x', shop_name: 'R Shop', city: 'Pune', gstin: '27AAPFU0939F1ZV' } })).s === 200 && app.db.prepare("SELECT s.gstin g FROM shops s JOIN users u ON u.id=s.owner_id WHERE u.phone='9555000001'").get().g === null, 'retailer signs up without GSTIN; any GSTIN sent is ignored');
  ok((await call('POST', '/api/signup', { body: { role: 'retailer', name: 'Weak', phone: '9333333333', password: '123', shop_name: 'W', city: 'Pune' } })).s === 400, 'weak password rejected');

  sec('2. CSRF, content type, headers');
  ok((await call('POST', '/api/me/prefs', { jar: sharma, body: { lang: 'hi' }, noCsrf: true })).s === 403, 'state-changing request without X-Requested-With -> 403');
  ok((await call('POST', '/api/me/prefs', { jar: sharma, body: { lang: 'hi' }, headers: { Origin: 'https://evil.example' } })).s === 403, 'cross-origin Origin header -> 403');
  ok((await call('POST', '/api/me/prefs', { jar: sharma, body: 'lang=hi', raw: true, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })).s === 415, 'non-JSON content type -> 415');
  const idx = await call('GET', '/'); const hh = idx.h;
  ok(/script-src 'self'/.test(hh.get('content-security-policy')) && !/unsafe-inline|unsafe-eval/.test(hh.get('content-security-policy')), 'CSP forbids inline/eval scripts and styles');
  ok(hh.get('x-content-type-options') === 'nosniff' && hh.get('x-frame-options') === 'DENY' && hh.get('referrer-policy') === 'no-referrer', 'nosniff, frame deny, no-referrer set');
  ok((await call('GET', '/../server.js')).s === 404 && (await call('GET', '/data/stocklink.db')).s === 404 && (await call('GET', '/%2e%2e/server.js')).s === 404 && (await call('GET', '/seed.js')).s === 404, 'no source/db files served (static whitelist)');
  ok((await call('POST', '/api/me/prefs', { jar: sharma, body: 'x'.repeat(40000), raw: true, headers: { 'Content-Type': 'application/json' } })).s === 413, 'oversized body -> 413');
  ok((await call('POST', '/api/me/prefs', { jar: sharma, body: '{bad', raw: true, headers: { 'Content-Type': 'application/json' } })).s === 400, 'malformed JSON -> 400, no crash');

  sec('3. Authorization (roles, tenants, IDOR)');
  ok((await call('GET', '/api/admin/stats', { jar: sharma })).s === 403 && (await call('GET', '/api/admin/stats', { jar: rahul })).s === 403, 'non-admin cannot reach admin API');
  ok((await call('GET', '/api/w/products', { jar: rahul })).s === 403, 'retailer cannot reach wholesaler API');
  ok((await call('GET', '/api/r/orders', { jar: sharma })).s === 403, 'wholesaler cannot reach retailer API');
  ok((await call('POST', '/api/admin/shops/1/verify', { jar: sharma, body: { action: 'approve' } })).s === 403, 'wholesaler cannot self-verify');
  const kc = await call('GET', '/api/r/catalog/' + WID, { jar: kul }); ok(kc.s === 403, 'unapproved retailer cannot read catalog');
  const rc = await call('GET', '/api/r/catalog/' + WID, { jar: rahul }); ok(rc.s === 200 && rc.j.products.length >= 6, 'approved retailer can read catalog');
  const mediaId = rc.j.products.find(p => p.media.length).media[0];
  ok((await call('GET', '/api/media/' + mediaId, { jar: rahul })).s === 200, 'approved retailer can fetch product photo');
  ok((await call('GET', '/api/media/' + mediaId, { jar: kul })).s === 404, 'unapproved retailer gets 404 for product photo (IDOR blocked)');
  ok((await call('GET', '/api/media/' + mediaId, { jar: patel })).s === 404, 'other wholesaler gets 404 for competitor photo');
  const pr = prodRow('6205');
  ok((await call('POST', '/api/r/orders', { jar: kul, body: { shop_id: WID, items: [{ product_id: pr.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'kul-try-0001' } })).s === 403, 'unapproved retailer cannot order');
  const ord = await call('GET', '/api/r/orders', { jar: rahul }); const rahulOrderId = ord.j.orders[0].id;
  ok((await call('POST', '/api/r/orders/' + rahulOrderId + '/cancel', { jar: kul, body: {} })).s === 404, "retailer cannot cancel another retailer's order");
  ok((await call('GET', '/api/orders/' + rahulOrderId + '/proof', { jar: kul })).s === 404, "retailer cannot read another retailer's payment proof");
  ok((await call('POST', '/api/w/orders/' + rahulOrderId + '/advance', { jar: patel, body: {} })).s === 404, "wholesaler cannot advance another wholesaler's order");
  ok((await call('POST', '/api/w/products/' + pr.id + '/stock', { jar: patel, body: { delta: 100 } })).s === 404, "wholesaler cannot change another wholesaler's stock");
  ok((await call('POST', '/api/w/connections/1', { jar: patel, body: { action: 'revoke' } })).s === 404, "wholesaler cannot touch another wholesaler's connections");
  ok((await call('POST', '/api/w/invites', { jar: patel, body: {} })).s === 403, 'unverified wholesaler cannot create invite codes');
  ok((await call('GET', '/api/shops/search?q=Patel', { jar: rahul })).j.shops.length === 0, 'unverified wholesaler hidden from search');
  const wl = await call('GET', '/api/w/retailers', { jar: sharma }); ok(!wl.j.connections.some(c => c.status === 'pending' && c.phone), 'pending retailer phone numbers not exposed to wholesaler');

  sec('4. Invite codes');
  A.resetLimits(); let r429 = 0, lastS = 0; for (let i = 0; i < 8; i++) { const r = await call('POST', '/api/r/join', { jar: kul, body: { code: 'ABCD' + String(1000 + i) } }); lastS = r.s; if (r.s === 429) r429++; }
  ok(r429 >= 3 && lastS === 429, 'invite-code guessing locked after 5 failures (' + r429 + ' blocked)');
  const attemptsKept = app.db.prepare('SELECT COUNT(*) n FROM code_attempts WHERE ok=0').get().n; ok(attemptsKept >= 5, 'failed attempts persisted (survive restart)');
  const joinKul = await call('POST', '/api/r/join', { jar: verma2, body: { code: 'K7QM-3XRP' } });
  ok(joinKul.s === 200 && joinKul.j.status === 'pending', 'valid code creates PENDING request, not access');
  ok((await call('GET', '/api/r/catalog/' + WID, { jar: verma2 })).s === 403, 'valid code alone does not unlock catalog');
  const codeRow = app.db.prepare('SELECT code_hash FROM invite_codes WHERE shop_id=?').get(WID); ok(!/K7QM|3XRP/i.test(codeRow.code_hash) && codeRow.code_hash.length >= 40, 'invite code stored only as keyed hash');
  const newCode = await call('POST', '/api/w/invites', { jar: sharma, body: { max_uses: 1, days: 1 } }); ok(newCode.s === 200 && /^[0-9A-Z]{4}-[0-9A-Z]{4}$/.test(newCode.j.code), 'wholesaler generates invite code');
  const lst = await call('GET', '/api/w/invites', { jar: sharma }); ok(!JSON.stringify(lst.j).includes(newCode.j.code.replace('-', '')), 'code is never returned again after creation');
  const inv = lst.j.invites[0]; await call('POST', '/api/w/invites/' + inv.id + '/revoke', { jar: sharma, body: {} });
  A.resetLimits(); ok((await call('POST', '/api/r/join', { jar: verma2, body: { code: newCode.j.code } })).s === 400, 'revoked code rejected with generic error');

  sec('5. Orders: stock integrity');
  const rid = (p) => app.db.prepare('SELECT * FROM products WHERE id=?').get(p);
  const chain = rid(prodRow('Roller chain').id); // on_hand 3
  // approve 12 retailers via direct DB (test fixture), then race for last units
  const racers = []; app.db.exec('BEGIN');
  for (let i = 0; i < 12; i++) {
    const uid = Number(app.db.prepare("INSERT INTO users(phone,name,role,pass_hash,tutorial_done,created_at) VALUES(?,?,?,?,1,?)").run('95000000' + String(10 + i), 'Racer ' + i, 'retailer', A.hashPasswordSync(PW), Date.now()).lastInsertRowid);
    const sid = Number(app.db.prepare("INSERT INTO shops(owner_id,type,name,city,verification,created_at) VALUES(?,?,?,?,?,?)").run(uid, 'retailer', 'Racer Shop ' + i, 'Pune', 'approved', Date.now()).lastInsertRowid);
    app.db.prepare("INSERT INTO connections(wholesaler_shop_id,retailer_shop_id,status,source,requested_at,decided_at) VALUES(?,?,?,?,?,?)").run(WID, sid, 'approved', 'request', Date.now(), Date.now());
    racers.push('95000000' + String(10 + i));
  }
  app.db.exec('COMMIT');
  const jars = []; for (const ph of racers) jars.push(await login(ph));
  const before = rid(chain.id), avail0 = before.on_hand - before.reserved;
  A.resetLimits();
  const results = await Promise.all(jars.map((j, i) => call('POST', '/api/r/orders', { jar: j, body: { shop_id: WID, items: [{ product_id: chain.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'race-' + i + '-abcdefgh' } })));
  const won = results.filter(r => r.s === 200).length, lost = results.filter(r => r.s === 409).length, after = rid(chain.id);
  ok(won === avail0 && lost === 12 - avail0, 'race: 12 retailers vs ' + avail0 + ' units -> exactly ' + won + ' succeed, ' + lost + ' rejected');
  ok(after.reserved === before.reserved + won && after.reserved <= after.on_hand, 'reserved count exact, never exceeds on_hand (reserved=' + after.reserved + ' on_hand=' + after.on_hand + ')');
  const p205 = prodRow('6205'); const b4 = rid(p205.id);
  const idem = { shop_id: WID, items: [{ product_id: p205.id, qty: 2 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'idem-double-0001' };
  const [d1, d2] = await Promise.all([call('POST', '/api/r/orders', { jar: rahul, body: idem }), call('POST', '/api/r/orders', { jar: rahul, body: idem })]);
  ok(d1.s === 200 && d2.s === 200 && d1.j.id === d2.j.id && rid(p205.id).reserved === b4.reserved + 2, 'double-submit with same idempotency key creates ONE order and reserves once');
  const cheat = await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty: 1, price_paise: 1, unit_price_paise: 1 }], price: 1, subtotal_paise: 1, fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'price-cheat-0001' } });
  ok(cheat.s === 200 && cheat.j.subtotal_paise === p205.price_paise, 'client-supplied price ignored; server price used (' + cheat.j.subtotal_paise + ')');
  for (const [qty, name] of [[-1, 'negative'], [0, 'zero'], [1.5, 'fractional'], ['5', 'string'], [1e12, 'huge'], [null, 'null']]) {
    const r = await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'qty-' + name + '-0001' } });
    ok(r.s === 400 || r.s === 409, 'quantity ' + name + ' rejected (' + r.s + ')');
  }
  const bad = (await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty: 1 }, { product_id: p205.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'dup-item-00001' } })); ok(bad.s === 400, 'duplicate line items rejected');
  const b2 = rid(prodRow('Bearing grease').id); const g = await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: b2.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'oos-order-00001' } }); ok(g.s === 409 && rid(b2.id).reserved === 0, 'out-of-stock item rejected, nothing reserved');
  ok((await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'bitcoin', idem_key: 'mode-bad-000001' } })).s === 400, 'unknown payment mode rejected');
  const rahulDb = app.db.prepare("SELECT s.id FROM shops s JOIN users u ON u.id=s.owner_id WHERE u.phone='9000000004'").get().id;
  app.db.prepare('UPDATE connections SET credit_allowed=0 WHERE retailer_shop_id=?').run(rahulDb);
  ok((await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'credit', idem_key: 'credit-not-0001' } })).s === 403, 'credit refused when wholesaler has not enabled it');
  app.db.prepare('UPDATE connections SET credit_allowed=1 WHERE retailer_shop_id=?').run(rahulDb);
  const mine = await call('GET', '/api/r/orders', { jar: rahul }); const o1 = mine.j.orders.find(o => o.id === d1.j.id);
  const rs0 = rid(p205.id).reserved; const cn = await call('POST', '/api/r/orders/' + o1.id + '/cancel', { jar: rahul, body: {} }); ok(cn.s === 200 && rid(p205.id).reserved === rs0 - 2, 'cancel releases reserved stock exactly');
  ok((await call('POST', '/api/r/orders/' + o1.id + '/cancel', { jar: rahul, body: {} })).s === 409 && rid(p205.id).reserved === rs0 - 2, 'double cancel cannot release stock twice');
  // payment/UTR logic
  const pay = cheat.j; ok((await call('POST', '/api/w/orders/' + pay.id + '/advance', { jar: sharma, body: {} })).s === 409, 'UPI order cannot be marked paid without a UTR');
  ok((await call('POST', '/api/r/orders/' + pay.id + '/payment', { jar: rahul, body: { utr: 'bad utr!' } })).s === 400, 'malformed UTR rejected');
  ok((await call('POST', '/api/r/orders/' + pay.id + '/payment', { jar: rahul, body: { utr: 'UTR412908877151' } })).s === 409, 'UTR already used on another order rejected (fraud: reused reference)');
  ok((await call('POST', '/api/r/orders/' + pay.id + '/payment', { jar: rahul, body: { utr: 'UTR555000111222', proof: 'data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==' } })).s === 400, 'HTML disguised as proof image rejected');
  ok((await call('POST', '/api/r/orders/' + pay.id + '/payment', { jar: rahul, body: { utr: 'UTR555000111222', proof: PNG } })).s === 200, 'valid UTR + PNG proof accepted');
  ok((await call('GET', '/api/orders/' + pay.id + '/proof', { jar: sharma })).s === 200 && (await call('GET', '/api/orders/' + pay.id + '/proof', { jar: patel })).s === 404, 'only the two parties can read the proof');
  for (const st of ['paid', 'packed', 'dispatched']) await call('POST', '/api/w/orders/' + pay.id + '/advance', { jar: sharma, body: {} });
  const done = await call('POST', '/api/w/orders/' + pay.id + '/advance', { jar: sharma, body: { pickup_code: 'ZZZZZZ' } }); ok(done.s === 403, 'pickup order cannot complete without the right code');
  const bdisp = rid(p205.id); ok(bdisp.on_hand === b4.on_hand - 1, 'dispatch deducts on_hand (and releases reservation)');
  ok(app.db.prepare('SELECT * FROM products WHERE reserved<0 OR on_hand<reserved').all().length === 0, 'DB invariant: no product has reserved<0 or reserved>on_hand');
  const bumped = await call('POST', '/api/w/products/' + chain.id + '/stock', { jar: sharma, body: { set: 0 } }); ok(bumped.s === 409, 'wholesaler cannot set stock below units reserved by open orders');

  ok((await call('POST', '/api/w/products/' + p205.id + '/stock', { jar: sharma, body: { delta: 5, reason: 'restock' } })).s === 200, 'wholesaler can adjust own stock (+5)');

  sec('6. Input validation, injection, uploads');
  const sqli = ["' OR '1'='1", "'; DROP TABLE users;--", '" OR 1=1 --', 'x%', '_'];
  for (const s of sqli) { const r = await call('GET', '/api/shops/search?q=' + encodeURIComponent(s), { jar: rahul }); ok(r.s === 200 && Array.isArray(r.j.shops), 'search handles injection string safely: ' + s.slice(0, 18)); }
  ok(app.db.prepare('SELECT COUNT(*) n FROM users').get().n > 6, 'users table intact after injection attempts');
  A.resetLimits(); ok((await call('POST', '/api/login', { body: { phone: "9000000002' OR '1'='1", password: "x' OR '1'='1" } })).s === 401, 'SQL injection in login fails');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'T', price: 10, on_hand: 1 } })).s === 400, 'too-short product name rejected');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Neg price', price: -5, on_hand: 1 } })).s === 400, 'negative price rejected');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Neg stock', price: 5, on_hand: -1 } })).s === 400, 'negative stock rejected');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Bad photo', price: 5, on_hand: 1, photos: ['data:image/svg+xml;base64,PHN2ZyBvbmxvYWQ9YWxlcnQoMSk+'] } })).s === 400, 'SVG upload rejected (script-capable image type)');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Fake png', price: 5, on_hand: 1, photos: ['data:image/png;base64,' + Buffer.from('<html><script>alert(1)</script></html>').toString('base64')] } })).s === 400, 'file with wrong magic bytes rejected even if labelled PNG');
  const bigImg = 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(700 * 1024)]).toString('base64');
  ok([400, 413].includes((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Big photo', price: 5, on_hand: 1, photos: [bigImg] } })).s), 'oversized image rejected');
  ok((await call('POST', '/api/w/products', { jar: sharma, body: { name: 'Five photos', price: 5, on_hand: 1, photos: [PNG, PNG, PNG, PNG, PNG] } })).s === 400, 'more than 4 photos rejected');
  const good = await call('POST', '/api/w/products', { jar: sharma, body: { name: '<script>alert(1)</script>', spec: 'x', price: 12.5, on_hand: 4, photos: [PNG] } }); ok(good.s === 200, 'valid product with photo created (HTML stored as inert text)');
  const gm = app.db.prepare('SELECT id FROM media WHERE product_id=?').get(good.j.id); const mr = await call('GET', '/api/media/' + gm.id, { jar: sharma });
  ok(mr.s === 200 && mr.h.get('content-type') === 'image/png' && /sandbox/.test(mr.h.get('content-security-policy')) && mr.h.get('x-content-type-options') === 'nosniff', 'media served with real MIME + CSP sandbox + nosniff');
  ok((await call('POST', '/api/w/profile', { jar: sharma, body: { upi_id: 'javascript:alert(1)' } })).s === 400, 'invalid UPI id rejected');
  ok((await call('POST', '/api/w/connections/1', { jar: sharma, body: { action: 'drop_table' } })).s === 400, 'unknown action rejected');
  ok((await call('GET', '/api/nope', { jar: sharma })).s === 404 && (await call('DELETE', '/api/w/orders', { jar: sharma })).s === 404, 'unknown routes/methods -> 404');

  sec('7. Revocation takes effect immediately');
  const sc = new Set(); const ev = await fetch(base + '/api/stream', { headers: { Cookie: rahul.c } }); ok(ev.status === 200 && /event-stream/.test(ev.headers.get('content-type')), 'SSE stream opens for authenticated user');
  const rd = ev.body.getReader(); const kcn = app.db.prepare('SELECT id FROM connections WHERE retailer_shop_id=? AND wholesaler_shop_id=?').get(rahulDb, WID);
  const pending = rd.read(); await call('POST', '/api/w/connections/' + kcn.id, { jar: sharma, body: { action: 'revoke' } });
  ok((await call('GET', '/api/r/catalog/' + WID, { jar: rahul })).s === 403, 'revoked retailer loses catalog access on next request');
  ok((await call('GET', '/api/media/' + mediaId, { jar: rahul })).s === 404, 'revoked retailer loses photo access');
  ok((await call('POST', '/api/r/orders', { jar: rahul, body: { shop_id: WID, items: [{ product_id: p205.id, qty: 1 }], fulfilment: 'pickup', payment_mode: 'upi', idem_key: 'after-revoke-001' } })).s === 403, 'revoked retailer cannot order');
  await rd.cancel().catch(() => {}); await call('POST', '/api/w/connections/' + kcn.id, { jar: sharma, body: { action: 'approve' } });
  const rv = app.db.prepare("SELECT id FROM users WHERE phone='9000000005'").get().id; app.db.prepare("UPDATE users SET status='suspended' WHERE id=?").run(rv); ok((await call('GET', '/api/me', { jar: verma2 })).s === 401, 'disabled account session stops working immediately');
  const whDis = app.db.prepare("SELECT owner_id FROM shops WHERE id=?").get(WID).owner_id; await call('POST', '/api/admin/shops/' + WID + '/verify', { jar: admin, body: { action: 'suspend', reason: 'test suspension' } });
  ok((await call('GET', '/api/r/catalog/' + WID, { jar: rahul })).s === 403, 'suspended wholesaler catalog disappears for retailers');
  await call('POST', '/api/admin/shops/' + WID + '/verify', { jar: admin, body: { action: 'reinstate' } });
  ok((await call('POST', '/api/admin/shops/' + WID + '/verify', { jar: admin, body: { action: 'reject' } })).s === 400, 'admin reject requires a reason');

  sec('8. Audit log integrity');
  const v1 = verifyAudit(app.db); ok(v1.ok && v1.checked > 20, 'audit chain verifies (' + v1.checked + ' entries)');
  const row = db2.prepare("SELECT id FROM audit_logs WHERE action='order_placed' ORDER BY id LIMIT 1").get();
  db2.prepare("UPDATE audit_logs SET detail='tampered' WHERE id=?").run(row.id);
  const v2 = verifyAudit(app.db); ok(!v2.ok && v2.broken_at === row.id, 'tampering with an entry is detected at entry ' + row.id);
  db2.prepare("UPDATE audit_logs SET detail=(SELECT detail FROM audit_logs WHERE id=?) WHERE id=?").run(row.id, row.id);
  const acts = app.db.prepare('SELECT DISTINCT action FROM audit_logs').all().map(r => r.action);
  for (const a of ['login', 'login_failed', 'order_placed', 'invite_created', 'invite_failed', 'shop_suspend', 'connection_revoke', 'stock_adjusted']) ok(acts.includes(a), 'audit has entry type: ' + a);
  ok(!JSON.stringify(app.db.prepare('SELECT detail FROM audit_logs').all()).includes(PW), 'no passwords in audit log');

  sec('9. Limits');
  A.resetLimits(); let g429 = 0; for (let i = 0; i < 40; i++) { const r = await call('POST', '/api/signup', { body: { role: 'retailer', name: 'Spam', phone: '97000001' + String(10 + i), password: 'Passw0rd!x', shop_name: 'Spam ' + i, city: 'Pune' } }); if (r.s === 429) g429++; }
  ok(g429 >= 25, 'signup spam rate limited (' + g429 + ' of 40 blocked)');
  await app.close(); db2.close(); fs.rmSync(dir, { recursive: true, force: true });
  console.log('\n=== ' + pass + ' passed, ' + fail + ' failed ===');
  if (fail) { console.log('FAILED:\n - ' + failures.join('\n - ')); process.exit(1); }
  process.exit(0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
