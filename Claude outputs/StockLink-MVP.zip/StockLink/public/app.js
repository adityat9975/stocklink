(() => {
'use strict';
const I = window.I18N;
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { cfg: null, me: null, lang: (navigator.language || 'en').toLowerCase().startsWith('hi') ? 'hi' : 'en', form: {}, authMode: 'login', tab: '', d: {},
  sel: { wid: null }, cart: { wid: null, items: {} }, checkout: null, modal: null, open: {}, live: false, authErr: '', pendingRefresh: false, busy: false };
const TABS = { retailer: ['catalog', 'orders', 'wholesalers'], wholesaler: ['today', 'retailers', 'stock', 'orders'], admin: ['shops', 'audit', 'stats'] };
const FLOW = ['received', 'paid', 'packed', 'dispatched', 'completed'];
const ER = { invalid_credentials: 'e_cred', rate_limited: 'e_rate', too_many_attempts: 'e_attempts', phone_taken: 'e_phone', weak_password: 'e_pw', invalid_phone: 'e_phone_inv',
  invalid_code: 'e_code', already_connected: 'e_already', insufficient_stock: 'e_stock', below_moq: 'e_moq', not_connected: 'e_notconn', shop_not_verified: 'e_notver',
  credit_not_allowed: 'e_credit', too_many_open_orders: 'e_open', payment_reference_missing: 'e_payref', wrong_pickup_code: 'e_pickup', utr_already_used: 'e_utr',
  invalid_utr: 'e_utr_inv', below_reserved: 'e_reserved', invalid_image: 'e_img', image_too_large: 'e_img', too_many_photos: 'e_photos', csrf: 'e_generic',
  invalid_gstin: 'e_gstin', gstin_required: 'e_gstin_req', gstin_taken: 'e_gstin_taken', invalid_upi_id: 'e_upi', too_many_active_codes: 'e_codes', product_unavailable: 'e_unavail', bad_state: 'e_state' };

const t = (k, v) => { let s = (I[S.lang] && I[S.lang][k]) ?? I.en[k] ?? k; if (v) for (const x in v) s = s.split('{' + x + '}').join(v[x]); return s; };
const money = (p) => ((S.cfg && S.cfg.currency) || '₹') + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: p % 100 ? 2 : 0, maximumFractionDigits: 2 });
const ago = (ts) => { const m = Math.max(0, Math.round((Date.now() - ts) / 60000)); if (m < 1) return t('just_now'); if (m < 60) return t('min_ago', { n: m }); const h = Math.round(m / 60); if (h < 48) return t('hr_ago', { n: h }); return t('day_ago', { n: Math.round(h / 24) }); };
const clock = (ts) => new Date(ts).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

async function api(method, url, body) {
  const opt = { method, headers: { 'X-Requested-With': 'StockLink' }, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(url, opt); let j = {};
  try { j = await r.json(); } catch (_) {}
  if (!r.ok) {
    const e = new Error(j.error || 'error'); e.status = r.status; e.data = j;
    if (r.status === 401 && url !== '/api/login' && S.me) { S.me = null; closeStream(); toast(t('e_session')); render(); }
    throw e;
  }
  return j;
}
const errText = (e) => {
  if (e.code === 'insufficient_stock' || (e.data && e.data.error === 'insufficient_stock')) return t('e_stock', { n: e.data.available ?? 0 });
  const k = ER[e.message] || 'e_generic'; return t(k, e.data || {});
};
let toastTimer;
function toast(msg) { const el = $('#toast'); el.innerHTML = '<div class="t" role="status">' + esc(msg) + '</div>'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.innerHTML = ''; }, 3600); }

/* ---------- live updates ---------- */
let es = null, liveTimer = null;
function openStream() {
  closeStream();
  es = new EventSource('/api/stream');
  es.onopen = () => { S.live = true; paintLive(); };
  es.onerror = () => { S.live = false; paintLive(); };
  for (const k of ['stock', 'order', 'conn', 'catalog']) es.addEventListener(k, () => { clearTimeout(liveTimer); liveTimer = setTimeout(refreshLive, 300); });
}
function closeStream() { if (es) { es.close(); es = null; } S.live = false; }
function paintLive() { const el = $('#livedot'); if (el) { el.className = 'livedot' + (S.live ? ' on' : ''); el.lastChild.textContent = S.live ? t('live') : t('offline'); } }
function typing() { const a = document.activeElement; return a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type !== 'checkbox' && a.type !== 'file'; }
async function refreshLive() { if (!S.me || S.modal) return; if (typing()) { S.pendingRefresh = true; return; } await load(true); }
document.addEventListener('focusout', () => { if (S.pendingRefresh) { S.pendingRefresh = false; setTimeout(() => { if (!typing()) refreshLive(); }, 200); } });

/* ---------- data loading ---------- */
async function load(silent) {
  const role = S.me.role, tab = S.tab;
  try {
    if (role === 'retailer') {
      const c = await api('GET', '/api/r/wholesalers'); S.d.conns = c.connections;
      const approved = c.connections.filter(x => x.status === 'approved' && x.verification === 'approved');
      if (!approved.find(x => x.shop_id === S.sel.wid)) S.sel.wid = approved.length ? approved[0].shop_id : null;
      if (tab === 'catalog' && S.sel.wid) { S.d.catalog = await api('GET', '/api/r/catalog/' + S.sel.wid); }
      else if (tab === 'catalog') S.d.catalog = null;
      if (tab === 'orders') S.d.orders = (await api('GET', '/api/r/orders')).orders;
    } else if (role === 'wholesaler') {
      S.me = Object.assign(S.me, { shop: (await api('GET', '/api/me')).shop });
      if (tab === 'today') S.d.dash = await api('GET', '/api/w/dashboard').catch(() => null);
      if (tab === 'retailers') { S.d.rconns = (await api('GET', '/api/w/retailers')).connections; S.d.invites = (await api('GET', '/api/w/invites')).invites; }
      if (tab === 'stock') S.d.products = (await api('GET', '/api/w/products')).products;
      if (tab === 'orders') S.d.orders = (await api('GET', '/api/w/orders')).orders;
      if (tab !== 'retailers') { S.d.pending = (await api('GET', '/api/w/retailers')).connections.filter(x => x.status === 'pending').length; }
    } else {
      if (tab === 'shops') S.d.shops = (await api('GET', '/api/admin/shops' + (S.open.allShops ? '' : '?status=pending'))).shops;
      if (tab === 'audit') S.d.audit = (await api('GET', '/api/admin/audit?limit=100')).logs;
      if (tab === 'stats') S.d.stats = await api('GET', '/api/admin/stats');
    }
  } catch (e) { if (!silent) toast(errText(e)); }
  render();
}
function go(tab) { S.tab = tab; S.checkout = null; S.d.verify = null; load(); }
async function boot() {
  try { S.cfg = await api('GET', '/api/config'); } catch (_) { S.cfg = { demo: false, currency: '₹', accounts: [] }; }
  try { const m = await api('GET', '/api/me'); await enter(m, true); } catch (_) { render(); }
}
async function enter(m, quiet) {
  S.me = Object.assign({}, m.user, { shop: m.shop }); S.lang = m.user.lang || S.lang; S.form = {}; S.d = {}; S.cart = { wid: null, items: {} };
  S.tab = TABS[S.me.role][0]; openStream(); await load(quiet);
  if (!S.me.tutorial_done) startTutorial();
}

/* ---------- views ---------- */
const langToggle = () => '<div class="lang" role="group" aria-label="Language"><button data-act="lang" data-id="en" aria-pressed="' + (S.lang === 'en') + '">English</button><button data-act="lang" data-id="hi" aria-pressed="' + (S.lang === 'hi') + '">Hinglish</button></div>';
const field = (id, label, type, extra) => '<div class="field"><label for="' + id + '">' + label + '</label><input id="' + id + '" data-f="' + id + '" type="' + (type || 'text') + '" value="' + esc(S.form[id] || '') + '" ' + (extra || '') + '></div>';

function authView() {
  const signup = S.authMode === 'signup', f = S.form;
  const demo = S.cfg.demo ? '<div class="demo"><b>' + t('demo_title') + '</b><span>' + t('demo_pw', { pw: S.cfg.demo_password }) + '</span><div class="chips">' +
    S.cfg.accounts.map(a => '<button class="chip" data-act="fill" data-id="' + esc(a.phone) + '">' + esc(a.label) + '</button>').join('') + '</div><span>' + t('demo_code', { code: S.cfg.demo_code }) + '</span></div>' : '';
  return '<div class="top"><div class="brand">Stock<span>Link</span></div>' + langToggle() + '</div><div class="auth"><div class="hero"><h1>' + t('hero') + '</h1><p>' + t('hero_sub') + '</p></div>' + demo +
    '<div class="seg"><button data-act="authmode" data-id="login" aria-pressed="' + !signup + '">' + t('login') + '</button><button data-act="authmode" data-id="signup" aria-pressed="' + signup + '">' + t('signup') + '</button></div>' +
    '<form data-form="' + (signup ? 'signup' : 'login') + '" class="card" novalidate>' +
    (signup ? '<div class="seg" role="group"><button type="button" data-act="role" data-id="retailer" aria-pressed="' + ((f.role || 'retailer') === 'retailer') + '">' + t('i_retailer') + '</button><button type="button" data-act="role" data-id="wholesaler" aria-pressed="' + (f.role === 'wholesaler') + '">' + t('i_wholesaler') + '</button></div>' +
      field('name', t('f_name'), 'text', 'autocomplete="name" maxlength="60"') : '') +
    field('phone', t('f_phone'), 'tel', 'autocomplete="tel" inputmode="tel" maxlength="16"') +
    field('password', t('f_password'), 'password', 'autocomplete="' + (signup ? 'new-password' : 'current-password') + '" maxlength="128"') +
    (signup ? field('shop_name', t('f_shop'), 'text', 'maxlength="80"') + field('city', t('f_city'), 'text', 'maxlength="60"') + (f.role === 'wholesaler' ? field('gstin', t('f_gstin'), 'text', 'maxlength="15" autocomplete="off" class="code"') : '') + '<p class="sub">' + (f.role === 'wholesaler' ? t('signup_w_note') : t('signup_r_note')) + '</p>' : '') +
    '<div class="err" role="alert">' + esc(S.authErr) + '</div><button class="btn pri block" type="submit"' + (S.busy ? ' disabled' : '') + '>' + (signup ? t('signup') : t('login')) + '</button></form>' +
    '<p class="sub">' + t('privacy') + '</p></div>';
}

function shell() {
  const m = S.me, role = m.role, tabs = TABS[role];
  const roleName = t('r_' + role);
  let body = '';
  if (role === 'retailer') body = S.checkout ? checkoutView() : S.tab === 'orders' ? rOrders() : S.tab === 'wholesalers' ? rShops() : rCatalog();
  else if (role === 'wholesaler') body = wBanner() + (S.tab === 'retailers' ? wRetailers() : S.tab === 'stock' ? wStock() : S.tab === 'orders' ? wOrders() : wToday());
  else body = S.tab === 'audit' ? aAudit() : S.tab === 'stats' ? aStats() : aShops();
  const cart = role === 'retailer' && S.tab === 'catalog' && !S.checkout ? cartBar() : '';
  return '<div class="top"><div class="brand">Stock<span>Link</span></div><div class="grp">' + langToggle() + '<button class="iconbtn" data-act="tutorial">' + t('help') + '</button><button class="iconbtn" data-act="logout">' + t('logout') + '</button></div></div>' +
    '<div class="who"><span><b>' + esc(m.shop ? m.shop.name : m.name) + '</b> · ' + roleName + '</span><span id="livedot" class="livedot' + (S.live ? ' on' : '') + '"><i></i><span>' + (S.live ? t('live') : t('offline')) + '</span></span></div>' +
    '<div class="screen">' + body + cart + '</div>' +
    '<nav class="nav">' + tabs.map(k => '<button data-act="tab" data-id="' + k + '"' + (S.tab === k ? ' aria-current="page"' : '') + '>' + t('t_' + k) + (role === 'wholesaler' && k === 'retailers' && S.d.pending > 0 ? '<span class="dot">' + S.d.pending + '</span>' : '') + '</button>').join('') + '</nav>';
}
const stockBadge = (p) => {
  if (p.status === 'paused') return '<span class="badge mute">' + t('paused') + '</span>';
  if (p.available <= 0) return '<span class="badge bad">' + t('out') + '</span>';
  if (p.available <= 5) return '<span class="badge warn"><i class="pulse"></i>' + t('only_left', { n: p.available }) + '</span>';
  return '<span class="badge good"><i class="pulse"></i>' + t('in_stock') + ' · ' + p.available + '</span>';
};
const noimg = () => '<div class="noimg" aria-hidden="true"><svg width="30" height="30" viewBox="0 0 34 34"><circle cx="17" cy="17" r="12" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="17" cy="17" r="3" fill="currentColor"/></svg></div>';
const thumb = (p) => p.media && p.media.length ? '<img class="thumb" alt="" loading="lazy" src="/api/media/' + p.media[0] + '">' : noimg();
const gallery = (p) => p.media && p.media.length > 0 ? '<div class="gal">' + p.media.map(id => '<img alt="' + esc(p.name) + '" loading="lazy" src="/api/media/' + id + '">').join('') + '</div>' : '';
const track = (o) => o.status === 'cancelled' || o.status === 'expired' ? '<div class="track x">' + FLOW.map(() => '<i class="on"></i>').join('') + '</div>' : '<div class="track">' + FLOW.map((_, i) => '<i class="' + (i <= FLOW.indexOf(o.status) ? 'on' : '') + '"></i>').join('') + '</div>';
const stLabel = (o) => t(o.status === 'dispatched' && o.fulfilment === 'pickup' ? 's_ready' : 's_' + o.status);
const stClass = (o) => o.status === 'cancelled' || o.status === 'expired' ? 'bad' : o.status === 'completed' ? 'good' : 'acc';

/* ----- retailer ----- */
function joinCard() {
  return '<div class="card"><h3>' + t('join_h') + '</h3><p class="sub">' + t('join_d') + '</p>' + field('code', t('invite_code'), 'text', 'class="code" autocomplete="off" maxlength="12" placeholder="' + t('code_ph') + '"') +
    '<button class="btn pri" data-act="join">' + t('join') + '</button></div>';
}
function rCatalog() {
  const cs = S.d.conns || [], approved = cs.filter(x => x.status === 'approved' && x.verification === 'approved');
  const pend = cs.filter(x => x.status === 'pending');
  if (!approved.length) return '<h2>' + t('locked') + '</h2><p class="sub">' + t('locked_d') + '</p>' + pend.map(c => '<div class="banner info"><b>' + esc(c.name) + '</b>: ' + t('pending_d') + '</div>').join('') + joinCard() + searchCard();
  const cat = S.d.catalog;
  if (!cat) return '<div class="empty">…</div>';
  const chips = approved.length > 1 ? '<div class="chips">' + approved.map(c => '<button class="chip" data-act="selw" data-id="' + c.shop_id + '" aria-pressed="' + (c.shop_id === S.sel.wid) + '">' + esc(c.name) + '</button>').join('') + '</div>' : '';
  return chips + '<div class="row sp"><div><h2>' + esc(cat.shop.name) + '</h2><p class="sub">' + esc(cat.shop.city) + ' · <span class="badge acc">' + t('verified') + '</span></p></div></div>' +
    (cat.products.length ? cat.products.map(productCard).join('') : '<div class="empty">' + t('no_products') + '</div>');
}
function productCard(p) {
  const q = (S.cart.wid === p.shop_id && S.cart.items[p.id]) || 0, can = p.status === 'active' && p.available > 0;
  return '<div class="card"><div class="prod">' + thumb(p) + '<div class="grow"><div class="name">' + esc(p.name) + (p.is_new ? ' <span class="badge acc">' + t('newtag') + '</span>' : '') + '</div><div class="sub">' + esc(p.spec) + '</div>' +
    '<div class="row sp mt"><span class="price">' + money(p.price_paise) + ' / ' + esc(p.unit) + '</span>' + stockBadge(p) + '</div><div class="fresh">' + t('ver', { t: ago(p.verified_at) }) + (p.moq > 1 ? ' · ' + t('moq', { n: p.moq }) : '') + '</div></div></div>' +
    (S.open['g' + p.id] ? gallery(p) : '') +
    '<div class="row sp"><button class="btn sm" data-act="gal" data-id="' + p.id + '">' + t(S.open['g' + p.id] ? 'hide_photos' : 'photos') + '</button>' +
    (can ? '<div class="stepper"><button data-act="cart" data-id="' + p.id + ':-1" aria-label="' + t('less') + '">−</button><b>' + q + '</b><button data-act="cart" data-id="' + p.id + ':1" aria-label="' + t('more') + '">+</button></div>' : '') + '</div></div>';
}
function cartBar() {
  const items = Object.entries(S.cart.items).filter(([, q]) => q > 0); if (!items.length || !S.d.catalog) return '';
  let total = 0, n = 0; for (const [id, q] of items) { const p = S.d.catalog.products.find(x => x.id === +id); if (p) { total += p.price_paise * q; n += q; } }
  return '<button class="cartbar" data-act="review"><span>' + t('cart_items', { n }) + '</span><span>' + t('review') + ' · ' + money(total) + '</span></button>';
}
function checkoutView() {
  const cat = S.d.catalog, co = S.checkout, conn = (S.d.conns || []).find(c => c.shop_id === S.cart.wid) || {};
  let total = 0; const lines = Object.entries(S.cart.items).filter(([, q]) => q > 0).map(([id, q]) => { const p = cat.products.find(x => x.id === +id); total += p.price_paise * q; return '<div class="row sp"><span>' + q + ' × ' + esc(p.name) + '</span><span class="price">' + money(p.price_paise * q) + '</span></div>'; }).join('');
  return '<button class="btn sm selfstart" data-act="cobk">← ' + t('back') + '</button><h2>' + t('checkout') + '</h2><div class="card">' + lines + '<div class="row sp"><b>' + t('total') + '</b><b class="price">' + money(total) + '</b></div></div>' +
    '<div class="card soft"><h3>' + t('fulfil') + '</h3><div class="seg"><button data-act="ful" data-id="pickup" aria-pressed="' + (co.fulfilment === 'pickup') + '">' + t('pickup') + '</button><button data-act="ful" data-id="home" aria-pressed="' + (co.fulfilment === 'home') + '">' + t('home') + '</button></div>' +
    (co.fulfilment === 'home' ? field('address', t('address'), 'text', 'maxlength="300" autocomplete="street-address"') : '<p class="sub">' + t('pickup_note') + '</p>') + '</div>' +
    '<div class="card soft"><h3>' + t('pay') + '</h3><div class="seg"><button data-act="pm" data-id="upi" aria-pressed="' + (co.mode === 'upi') + '">UPI</button><button data-act="pm" data-id="credit" aria-pressed="' + (co.mode === 'credit') + '"' + (conn.credit_allowed ? '' : ' disabled') + '>' + t('p_credit') + '</button><button data-act="pm" data-id="cod" aria-pressed="' + (co.mode === 'cod') + '">' + t('p_cod') + '</button></div>' +
    '<p class="sub">' + (co.mode === 'upi' ? t('upi_note', { upi: conn.upi_id || cat.shop.upi_id || '—' }) : co.mode === 'credit' ? t('credit_note') : t('cod_note')) + '</p></div>' +
    '<p class="sub">' + t('reserve_note') + '</p><button class="btn pri block" data-act="place"' + (S.busy ? ' disabled' : '') + '>' + t('place') + '</button>';
}
function rOrders() {
  const os = S.d.orders; if (!os) return '<div class="empty">…</div>'; if (!os.length) return '<h2>' + t('t_orders') + '</h2><div class="empty">' + t('no_orders') + '</div>';
  return '<h2>' + t('t_orders') + '</h2>' + os.map(o => {
    const live = !['completed', 'cancelled', 'expired'].includes(o.status);
    return '<div class="card"><div class="row sp"><div><b>' + o.no + '</b> <span class="sub">· ' + esc(o.wholesaler.name) + '</span></div><span class="badge ' + stClass(o) + '">' + stLabel(o) + '</span></div>' +
      o.items.map(i => '<div class="sub">' + i.qty + ' × ' + esc(i.name) + ' · ' + money(i.unit_price_paise) + '</div>').join('') + track(o) +
      '<div class="row sp"><span class="sub">' + t(o.fulfilment === 'home' ? 'home' : 'pickup') + ' · ' + t('pm_' + o.payment_mode) + '</span><span class="price">' + money(o.subtotal_paise) + '</span></div>' +
      (o.fulfilment === 'pickup' && live ? '<div class="card soft"><span class="sub">' + t('pickup_code') + '</span><span class="pick">' + esc(o.pickup_code) + '</span><span class="sub">' + t('pickup_code_d') + '</span></div>' : '') +
      (o.payment_mode === 'upi' && o.status === 'received' && !o.utr ? '<div class="card soft"><h3>' + t('pay_now') + '</h3><p class="sub">' + t('pay_now_d', { upi: o.wholesaler.upi_id || '—', amt: money(o.subtotal_paise) }) + '</p>' +
        field('utr_' + o.id, t('utr'), 'text', 'class="code" maxlength="30" autocomplete="off"') + '<label class="btn sm" for="proof_' + o.id + '">' + t(S.form['proof_' + o.id] ? 'proof_ok' : 'proof_add') + '</label><input class="vh" type="file" accept="image/*" id="proof_' + o.id + '" data-proof="' + o.id + '"><button class="btn pri sm" data-act="paysubmit" data-id="' + o.id + '">' + t('submit_pay') + '</button></div>' : '') +
      (o.utr ? '<div class="sub">' + t('utr') + ': <span class="mono">' + esc(o.utr) + '</span> · ' + t(o.status === 'received' ? 'verify_wait' : 'verified') + '</div>' : '') +
      (o.cancel_reason && !live ? '<div class="sub">' + esc(o.cancel_reason) + '</div>' : '') +
      (o.status === 'received' ? '<div class="row"><button class="btn bad sm" data-act="rcancel" data-id="' + o.id + '">' + t('cancel_order') + '</button></div>' : '') + '</div>';
  }).join('');
}
function searchCard() {
  const res = S.d.search || [];
  return '<div class="card"><h3>' + t('find_h') + '</h3>' + field('q', t('find_ph'), 'text', 'maxlength="40" autocomplete="off"') + '<button class="btn" data-act="search">' + t('search') + '</button>' +
    res.map(s => '<div class="row sp"><div class="grow"><div class="name">' + esc(s.name) + '</div><div class="sub">' + esc(s.city) + '</div></div>' +
      (s.conn === 'approved' ? '<span class="badge good">' + t('connected') + '</span>' : s.conn === 'pending' ? '<span class="badge mute">' + t('pending') + '</span>' : s.conn === 'blocked' ? '' : '<button class="btn sm" data-act="reqaccess" data-id="' + s.id + '">' + t('request') + '</button>') + '</div>').join('') +
    (S.open.searched && !res.length ? '<p class="sub">' + t('no_results') + '</p>' : '') + '</div>';
}
function rShops() {
  const cs = S.d.conns; if (!cs) return '<div class="empty">…</div>';
  return '<h2>' + t('my_wh') + '</h2>' + (cs.length ? cs.map(c => '<div class="card"><div class="row sp"><div><div class="name">' + esc(c.name) + '</div><p class="sub">' + esc(c.city) + (c.status === 'approved' && c.credit_allowed ? ' · ' + t('credit_ok') : '') + '</p></div>' +
    '<span class="badge ' + (c.status === 'approved' ? 'good' : c.status === 'pending' ? 'mute' : 'bad') + '">' + t('cs_' + c.status) + '</span></div></div>').join('') : '<div class="empty">' + t('no_wh') + '</div>') + joinCard() + searchCard();
}

/* ----- wholesaler ----- */
function wBanner() {
  const v = S.me.shop && S.me.shop.verification;
  if (v === 'approved') return '';
  return '<div class="banner">' + t('ver_' + v) + (S.me.shop.reject_reason ? ' ' + esc(S.me.shop.reject_reason) : '') + '</div>';
}
function wToday() {
  const d = S.d.dash, sh = S.me.shop;
  return '<h2>' + esc(sh.name) + '</h2>' + (d ? '<div class="stats"><div class="stat"><b>' + d.open_orders + '</b><span>' + t('st_orders') + '</span></div><div class="stat"><b>' + d.pending_requests + '</b><span>' + t('st_pending') + '</span></div>' +
    '<div class="stat"><b>' + d.low_stock + '</b><span>' + t('st_low') + '</span></div><div class="stat"><b>' + d.reserved_units + '</b><span>' + t('st_res') + '</span></div></div>' +
    '<div class="stat"><b>' + money(d.confirmed_value_paise) + '</b><span>' + t('st_value') + '</span></div>' : '') +
    '<div class="card"><h3>' + t('upi_h') + '</h3><p class="sub">' + t('upi_d') + '</p>' + (sh.upi_id ? '<div class="mono">' + esc(sh.upi_id) + '</div>' : '') +
    field('upi_id', t('upi_ph'), 'text', 'maxlength="80" autocomplete="off"') + '<button class="btn sm" data-act="saveupi">' + t('save') + '</button></div>';
}
function wRetailers() {
  const cs = S.d.rconns || [], inv = S.d.invites || [];
  const pending = cs.filter(c => c.status === 'pending'), rest = cs.filter(c => c.status !== 'pending');
  return '<h2>' + t('t_retailers') + '</h2><h3>' + t('new_req') + '</h3>' +
    (pending.length ? pending.map(c => '<div class="card"><div class="name">' + esc(c.name) + '</div><p class="sub">' + esc(c.city) + ' · ' + t(c.source === 'invite_code' ? 'via_code' : 'via_req') + ' · ' + ago(c.requested_at) + '</p><div class="row"><button class="btn good sm" data-act="conn" data-id="' + c.id + ':approve">' + t('approve') + '</button><button class="btn bad sm" data-act="conn" data-id="' + c.id + ':decline">' + t('decline') + '</button></div></div>').join('') : '<div class="empty">' + t('no_req') + '</div>') +
    '<div class="card"><h3>' + t('invite_h') + '</h3><p class="sub">' + t('invite_d') + '</p><div class="row"><div class="field grow"><label for="imax">' + t('max_uses') + '</label><input id="imax" data-f="imax" type="number" min="1" max="100" value="' + esc(S.form.imax || '5') + '"></div>' +
    '<div class="field grow"><label for="idays">' + t('valid_days') + '</label><input id="idays" data-f="idays" type="number" min="1" max="30" value="' + esc(S.form.idays || '7') + '"></div></div>' +
    '<label class="row sub"><input type="checkbox" id="iauto"' + (S.form.iauto ? ' checked' : '') + '> ' + t('auto') + '</label><button class="btn pri" data-act="newinvite">' + t('gen_code') + '</button>' +
    inv.map(i => '<div class="row sp"><div class="mono">••••-••' + esc(i.hint) + '</div><span class="sub">' + t('uses', { u: i.uses, m: i.max_uses }) + (i.auto_approve ? ' · ' + t('auto_short') : '') + '</span>' + (i.active ? '<button class="btn bad sm" data-act="revinvite" data-id="' + i.id + '">' + t('revoke_code') + '</button>' : '<span class="badge mute">' + t('inactive') + '</span>') + '</div>').join('') + '</div>' +
    '<h3>' + t('connected_h') + '</h3>' + (rest.length ? rest.map(c => '<div class="card"><div class="row sp"><div><div class="name">' + esc(c.name) + '</div><p class="sub">' + esc(c.city) + (c.phone ? ' · ' + esc(c.phone) : '') + '</p></div><span class="badge ' + (c.status === 'approved' ? 'good' : 'bad') + '">' + t('cs_' + c.status) + '</span></div>' +
      '<div class="chips">' + (c.status === 'approved' ? '<button class="btn sm" data-act="conn" data-id="' + c.id + ':credit:' + (c.credit_allowed ? 0 : 1) + '">' + t(c.credit_allowed ? 'credit_off' : 'credit_on') + '</button><button class="btn bad sm" data-act="conn" data-id="' + c.id + ':revoke">' + t('revoke') + '</button>' : '') +
      (c.status === 'revoked' || c.status === 'rejected' ? '<button class="btn sm" data-act="conn" data-id="' + c.id + ':approve">' + t('approve') + '</button>' : '') + (c.status !== 'blocked' ? '<button class="btn bad sm" data-act="conn" data-id="' + c.id + ':block">' + t('block') + '</button>' : '') + '</div></div>').join('') : '<div class="empty">–</div>');
}
function wStock() {
  const ps = S.d.products; if (!ps) return '<div class="empty">…</div>'; const f = S.form;
  return '<h2>' + t('t_stock') + '</h2>' + ps.map(p => '<div class="card"><div class="prod">' + thumb(p) + '<div class="grow"><div class="name">' + esc(p.name) + '</div><div class="sub">' + money(p.price_paise) + ' · ' + p.on_hand + ' ' + t('onhand') + ' · ' + p.reserved + ' ' + t('res') + '</div><div class="row sp mt">' + stockBadge(p) + '</div><div class="fresh">' + t('ver', { t: ago(p.verified_at) }) + '</div></div></div>' +
    '<div class="chips"><button class="btn sm" data-act="stock" data-id="' + p.id + ':-1">' + t('adj_m') + '</button><button class="btn sm" data-act="stock" data-id="' + p.id + ':10">' + t('adj_p') + '</button><button class="btn sm" data-act="pst" data-id="' + p.id + ':' + (p.status === 'paused' ? 'active' : 'paused') + '">' + t(p.status === 'paused' ? 'resume' : 'pause') + '</button><button class="btn sm" data-act="markv" data-id="' + p.id + '">' + t('markv') + '</button></div>' +
    '<details><summary class="sub">' + t('more') + '</summary><div class="row wrap mt">' + field('set_' + p.id, t('set_count'), 'number', 'min="0"') + field('price_' + p.id, t('set_price'), 'number', 'min="0" step="0.01"') + '</div><div class="chips mt"><button class="btn sm" data-act="setstock" data-id="' + p.id + '">' + t('set_count_btn') + '</button><button class="btn sm" data-act="setprice" data-id="' + p.id + '">' + t('set_price_btn') + '</button><button class="btn sm" data-act="addphoto" data-id="' + p.id + '">' + t('add_more_photos') + '</button><button class="btn bad sm" data-act="pst" data-id="' + p.id + ':archived">' + t('archive') + '</button></div></details></div>').join('') +
    '<div class="card soft"><h3>' + t('add') + '</h3><div class="prev">' + (f.photos || []).map((u, i) => '<div><img alt="" src="' + u + '"><button data-act="rmphoto" data-id="' + i + '" aria-label="' + t('rm') + '">×</button></div>').join('') + '</div>' +
    '<label class="btn sm" for="aPhotos">' + t('add_photos') + '</label><input class="vh" type="file" id="aPhotos" accept="image/*" multiple>' +
    field('pname', t('add_name'), 'text', 'maxlength="100"') + field('pspec', t('add_spec'), 'text', 'maxlength="200"') + '<div class="row">' + field('pprice', t('add_price'), 'number', 'min="0" step="0.01" inputmode="decimal"') + field('pstock', t('add_stock'), 'number', 'min="0" inputmode="numeric"') + field('pmoq', t('add_moq'), 'number', 'min="1" inputmode="numeric"') + '</div>' +
    '<button class="btn pri" data-act="addp">' + t('add_btn') + '</button></div>';
}
function wOrders() {
  const os = S.d.orders; if (!os) return '<div class="empty">…</div>'; if (!os.length) return '<h2>' + t('t_orders') + '</h2><div class="empty">' + t('no_orders') + '</div>';
  return '<h2>' + t('t_orders') + '</h2>' + os.map(o => {
    const i = FLOW.indexOf(o.status), canCancel = ['received', 'paid', 'packed'].includes(o.status), done = i < 0 || i >= FLOW.length - 1;
    let nx = '';
    if (!done) {
      if (o.status === 'received') nx = o.payment_mode === 'upi' && !o.utr ? '<span class="sub">' + t('wait_utr') + '</span>' : '<button class="btn pri sm" data-act="adv" data-id="' + o.id + '">' + t(o.payment_mode === 'upi' ? 'nx_upi' : o.payment_mode === 'credit' ? 'nx_credit' : 'nx_cod') + '</button>';
      else if (o.status === 'paid') nx = '<button class="btn pri sm" data-act="adv" data-id="' + o.id + '">' + t('nx_pack') + '</button>';
      else if (o.status === 'packed') nx = '<button class="btn pri sm" data-act="adv" data-id="' + o.id + '">' + t(o.fulfilment === 'pickup' ? 'nx_ready' : 'nx_disp') + '</button>';
      else if (o.status === 'dispatched') nx = o.fulfilment === 'pickup' ? '<div class="row grow">' + field('pc_' + o.id, t('pickup_code'), 'text', 'class="code" maxlength="8" autocomplete="off"') + '<button class="btn pri sm" data-act="adv" data-id="' + o.id + '">' + t('nx_done') + '</button></div>' : '<button class="btn pri sm" data-act="adv" data-id="' + o.id + '">' + t('nx_done') + '</button>';
    }
    return '<div class="card"><div class="row sp"><div><b>' + o.no + '</b> <span class="sub">· ' + esc(o.retailer.name) + '</span></div><span class="badge ' + stClass(o) + '">' + stLabel(o) + '</span></div>' +
      o.items.map(x => '<div class="sub">' + x.qty + ' × ' + esc(x.name) + '</div>').join('') + track(o) +
      '<div class="row sp"><span class="sub">' + t(o.fulfilment === 'home' ? 'home' : 'pickup') + ' · ' + t('pm_' + o.payment_mode) + '</span><span class="price">' + money(o.subtotal_paise) + '</span></div>' +
      (o.address ? '<div class="sub">' + esc(o.address) + '</div>' : '') +
      (o.utr ? '<div class="sub">' + t('utr') + ': <span class="mono">' + esc(o.utr) + '</span>' + (o.has_proof ? ' · <a href="/api/orders/' + o.id + '/proof" target="_blank" rel="noopener">' + t('view_proof') + '</a>' : '') + '</div>' : '') +
      '<div class="row wrap">' + nx + (canCancel ? '<button class="btn bad sm" data-act="wcancel" data-id="' + o.id + '">' + t('cancel_order') + '</button>' : '') + '</div></div>';
  }).join('');
}

/* ----- admin ----- */
function aShops() {
  const sh = S.d.shops; if (!sh) return '<div class="empty">…</div>';
  return '<h2>' + t('v_h') + '</h2><div class="chips"><button class="chip" data-act="shopfilter" data-id="pending" aria-pressed="' + !S.open.allShops + '">' + t('v_pending') + '</button><button class="chip" data-act="shopfilter" data-id="all" aria-pressed="' + !!S.open.allShops + '">' + t('all') + '</button></div>' +
    (sh.length ? sh.map(s => '<div class="card"><div class="row sp"><div><div class="name">' + esc(s.name) + '</div><p class="sub">' + t('r_' + s.type) + ' · ' + esc(s.city) + ' · ' + esc(s.owner) + ' · ' + esc(s.phone) + (s.gstin ? ' · ' + esc(s.gstin) : '') + '</p>' + (s.type === 'wholesaler' ? '<p class="sub">' + (s.gstin ? t(s.gstin_valid ? 'gst_fmt_ok' : 'gst_fmt_bad') + (s.gstin_state ? ' · ' + t('gst_state', { s: esc(s.gstin_state) }) : '') + ' · <a href="https://services.gst.gov.in/services/searchtp" target="_blank" rel="noopener noreferrer">' + t('gst_portal') + '</a>' : t('gst_none')) + '</p>' : '') + '</div><span class="badge ' + (s.verification === 'approved' ? 'good' : s.verification === 'pending' ? 'warn' : 'bad') + '">' + t('vs_' + s.verification) + '</span></div>' +
      field('reason_' + s.id, t('reason'), 'text', 'maxlength="200"') + '<div class="chips">' + (s.verification !== 'approved' ? '<button class="btn good sm" data-act="verify" data-id="' + s.id + ':approve">' + t('approve') + '</button>' : '<button class="btn bad sm" data-act="verify" data-id="' + s.id + ':suspend">' + t('suspend') + '</button>') +
      (s.verification === 'pending' ? '<button class="btn bad sm" data-act="verify" data-id="' + s.id + ':reject">' + t('decline') + '</button>' : '') + '</div></div>').join('') : '<div class="empty">' + t('v_none') + '</div>');
}
function aAudit() {
  const lg = S.d.audit; if (!lg) return '<div class="empty">…</div>'; const v = S.d.verify;
  return '<h2>' + t('audit_h') + '</h2><div class="row"><button class="btn sm" data-act="verifychain">' + t('verify_chain') + '</button></div>' +
    (v ? '<div class="banner ' + (v.ok ? 'info' : '') + '">' + (v.ok ? t('chain_ok', { n: v.checked }) : t('chain_bad', { id: v.broken_at })) + '</div>' : '') +
    lg.map(a => '<div class="log"><time>' + clock(a.ts) + '</time><span><b>' + esc(a.actor_label || '–') + '</b> ' + esc(a.action) + (a.detail ? ' · ' + esc(a.detail) : '') + '</span></div>').join('');
}
function aStats() {
  const s = S.d.stats; if (!s) return '<div class="empty">…</div>';
  const n = (arr, k, v) => (arr.find(x => x[k] === v) || {}).n || 0;
  const gmv = s.orders.filter(o => ['paid', 'packed', 'dispatched', 'completed'].includes(o.status)).reduce((a, o) => a + o.paise, 0);
  const orders = s.orders.reduce((a, o) => a + o.n, 0);
  return '<h2>' + t('t_stats') + '</h2><div class="stats"><div class="stat"><b>' + n(s.users, 'role', 'wholesaler') + '</b><span>' + t('r_wholesaler') + '</span></div><div class="stat"><b>' + n(s.users, 'role', 'retailer') + '</b><span>' + t('r_retailer') + '</span></div>' +
    '<div class="stat"><b>' + s.shops.filter(x => x.type === 'wholesaler' && x.verification === 'pending').reduce((a, x) => a + x.n, 0) + '</b><span>' + t('v_pending') + '</span></div><div class="stat"><b>' + orders + '</b><span>' + t('t_orders') + '</span></div></div>' +
    '<div class="stat"><b>' + money(gmv) + '</b><span>' + t('gmv') + '</span></div>' + (S.cfg.demo ? '<div class="card"><h3>' + t('demo_reset_h') + '</h3><p class="sub">' + t('demo_reset_d') + '</p><button class="btn bad sm" data-act="resetdemo">' + t('demo_reset') + '</button></div>' : '');
}

/* ---------- tutorial ---------- */
const TUT = { retailer: ['r1', 'r2', 'r3', 'r4', 'r5'], wholesaler: ['w1', 'w2', 'w3', 'w4', 'w5'], admin: ['a1', 'a2', 'a3'] };
function startTutorial() { S.modal = { type: 'tut', i: 0 }; render(); }
function modalView() {
  const m = S.modal;
  if (m.type === 'code') return '<div class="modal" role="dialog" aria-modal="true"><div class="sheet"><h2>' + t('code_new') + '</h2><div class="codebox">' + esc(m.code) + '</div><p class="sub">' + t('code_once') + '</p><div class="row"><button class="btn" data-act="copycode">' + t('copy') + '</button><button class="btn pri" data-act="closemodal">' + t('done') + '</button></div></div></div>';
  const steps = TUT[S.me.role], k = steps[m.i], last = m.i === steps.length - 1;
  return '<div class="modal" role="dialog" aria-modal="true" aria-label="' + t('tut_label') + '"><div class="sheet"><div class="row sp"><div class="dots">' + steps.map((_, i) => '<i class="' + (i === m.i ? 'on' : '') + '"></i>').join('') + '</div><button class="iconbtn" data-act="tutskip">' + t('skip') + '</button></div>' +
    '<div class="tutbig" aria-hidden="true">' + t(k + '_i') + '</div><h2>' + t(k + '_t') + '</h2><p>' + t(k + '_b', { code: S.cfg.demo_code || '' }) + '</p>' +
    '<div class="row sp"><button class="btn" data-act="tutback"' + (m.i === 0 ? ' disabled' : '') + '>' + t('back') + '</button><button class="btn pri" data-act="' + (last ? 'tutdone' : 'tutnext') + '">' + t(last ? 'start' : 'next') + '</button></div></div></div>';
}
function endTutorial() { S.modal = null; if (S.me && !S.me.tutorial_done) { S.me.tutorial_done = true; api('POST', '/api/me/prefs', { tutorial_done: true }).catch(() => {}); } render(); }

/* ---------- render ---------- */
function render() {
  const root = $('#root'); if (!root) return;
  const a = document.activeElement, fid = a && a.id && root.contains(a) ? a.id : null, sel = a && a.selectionStart != null ? [a.selectionStart, a.selectionEnd] : null, y = window.scrollY;
  document.documentElement.lang = S.lang === 'hi' ? 'hi-Latn' : 'en';
  root.innerHTML = !S.cfg ? '' : !S.me ? authView() : shell();
  if (S.me && S.modal) root.insertAdjacentHTML('beforeend', modalView());
  window.scrollTo(0, y);
  if (fid) { const el = document.getElementById(fid); if (el) { el.focus({ preventScroll: true }); if (sel && el.setSelectionRange && /^(text|tel|password|search)$/.test(el.type)) { try { el.setSelectionRange(sel[0], sel[1]); } catch (_) {} } } }
}

/* ---------- images ---------- */
function shrink(file) {
  return new Promise((res, rej) => {
    if (!/^image\//.test(file.type)) return rej(new Error('x'));
    const url = URL.createObjectURL(file), im = new Image();
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('x')); };
    im.onload = () => { const k = Math.min(1, 720 / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.82)); };
    im.src = url;
  });
}

/* ---------- actions ---------- */
const withBusy = async (fn) => { if (S.busy) return; S.busy = true; render(); try { await fn(); } finally { S.busy = false; render(); } };
const ACT = {
  lang: async (id) => { S.lang = id; render(); if (S.me) api('POST', '/api/me/prefs', { lang: id }).catch(() => {}); },
  authmode: (id) => { S.authMode = id; S.authErr = ''; render(); },
  role: (id) => { S.form.role = id; render(); },
  fill: (id) => { S.form.phone = id; S.form.password = S.cfg.demo_password; S.authMode = 'login'; render(); },
  logout: async () => { try { await api('POST', '/api/logout', {}); } catch (_) {} closeStream(); S.me = null; S.form = {}; S.modal = null; render(); },
  tab: (id) => go(id),
  tutorial: () => startTutorial(), tutnext: () => { S.modal.i++; render(); }, tutback: () => { S.modal.i = Math.max(0, S.modal.i - 1); render(); }, tutskip: () => endTutorial(), tutdone: () => endTutorial(),
  closemodal: () => { S.modal = null; render(); },
  copycode: async () => { try { await navigator.clipboard.writeText(S.modal.code); toast(t('copied')); } catch (_) { toast(S.modal.code); } },
  selw: (id) => { S.sel.wid = +id; S.d.catalog = null; load(); },
  gal: (id) => { S.open['g' + id] = !S.open['g' + id]; render(); },
  cart: (id) => {
    const [pid, d] = id.split(':').map(Number), p = S.d.catalog.products.find(x => x.id === pid);
    if (S.cart.wid !== p.shop_id) S.cart = { wid: p.shop_id, items: {} };
    let q = (S.cart.items[pid] || 0) + d;
    if (d > 0 && q < p.moq) q = p.moq; if (q < p.moq) q = 0; if (q > p.available) { q = p.available; toast(t('e_stock', { n: p.available })); }
    S.cart.items[pid] = q; render();
  },
  review: () => { S.checkout = { idem: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random()), fulfilment: 'pickup', mode: 'upi' }; S.form.address = S.form.address || ''; render(); },
  cobk: () => { S.checkout = null; render(); }, ful: (id) => { S.checkout.fulfilment = id; render(); }, pm: (id) => { S.checkout.mode = id; render(); },
  place: () => withBusy(async () => {
    const items = Object.entries(S.cart.items).filter(([, q]) => q > 0).map(([id, q]) => ({ product_id: +id, qty: q })), co = S.checkout;
    try {
      const o = await api('POST', '/api/r/orders', { shop_id: S.cart.wid, items, fulfilment: co.fulfilment, address: co.fulfilment === 'home' ? (S.form.address || '') : undefined, payment_mode: co.mode, idem_key: co.idem });
      S.cart = { wid: null, items: {} }; S.checkout = null; S.tab = 'orders'; toast(t('placed', { id: o.no })); await load(true);
    } catch (e) { toast(errText(e)); if (e.message === 'insufficient_stock') { S.checkout = null; await load(true); } }
  }),
  rcancel: async (id) => { try { await api('POST', '/api/r/orders/' + id + '/cancel', {}); toast(t('cancelled')); await load(true); } catch (e) { toast(errText(e)); } },
  paysubmit: async (id) => {
    try { await api('POST', '/api/r/orders/' + id + '/payment', { utr: S.form['utr_' + id] || '', proof: S.form['proof_' + id] || undefined }); delete S.form['utr_' + id]; delete S.form['proof_' + id]; toast(t('pay_sent')); await load(true); } catch (e) { toast(errText(e)); }
  },
  join: () => withBusy(async () => { try { const r = await api('POST', '/api/r/join', { code: S.form.code || '' }); S.form.code = ''; toast(t(r.status === 'approved' ? 'joined' : 'join_pending')); await load(true); } catch (e) { toast(errText(e)); } }),
  search: async () => { try { S.d.search = (await api('GET', '/api/shops/search?q=' + encodeURIComponent(S.form.q || ''))).shops; S.open.searched = true; render(); } catch (e) { toast(errText(e)); } },
  reqaccess: async (id) => { try { await api('POST', '/api/r/request', { wholesaler_shop_id: +id }); toast(t('req_sent')); S.d.search = (await api('GET', '/api/shops/search?q=' + encodeURIComponent(S.form.q || ''))).shops; await load(true); } catch (e) { toast(errText(e)); } },
  /* wholesaler */
  saveupi: async () => { try { await api('POST', '/api/w/profile', { upi_id: S.form.upi_id || '' }); S.form.upi_id = ''; toast(t('saved')); await load(true); } catch (e) { toast(errText(e)); } },
  conn: async (id) => { const [cid, action, v] = id.split(':'); try { await api('POST', '/api/w/connections/' + cid, action === 'credit' ? { action, allowed: v === '1' } : { action }); await load(true); } catch (e) { toast(errText(e)); } },
  newinvite: async () => { try { const r = await api('POST', '/api/w/invites', { max_uses: +(S.form.imax || 5), days: +(S.form.idays || 7), auto_approve: $('#iauto') ? $('#iauto').checked : false }); S.modal = { type: 'code', code: r.code }; await load(true); render(); } catch (e) { toast(errText(e)); } },
  revinvite: async (id) => { try { await api('POST', '/api/w/invites/' + id + '/revoke', {}); await load(true); } catch (e) { toast(errText(e)); } },
  stock: async (id) => { const [pid, d] = id.split(':'); try { await api('POST', '/api/w/products/' + pid + '/stock', { delta: +d, reason: +d < 0 ? 'counter sale' : 'restock' }); await load(true); } catch (e) { toast(errText(e)); } },
  setstock: async (id) => { try { await api('POST', '/api/w/products/' + id + '/stock', { set: S.form['set_' + id] === undefined || S.form['set_' + id] === '' ? NaN : Number(S.form['set_' + id]), reason: 'stock count' }); delete S.form['set_' + id]; await load(true); } catch (e) { toast(errText(e)); } },
  setprice: async (id) => { try { await api('POST', '/api/w/products/' + id + '/update', { price: Number(S.form['price_' + id]) }); delete S.form['price_' + id]; toast(t('saved')); await load(true); } catch (e) { toast(errText(e)); } },
  pst: async (id) => { const [pid, st] = id.split(':'); try { await api('POST', '/api/w/products/' + pid + '/status', { status: st }); await load(true); } catch (e) { toast(errText(e)); } },
  markv: async (id) => { try { await api('POST', '/api/w/products/' + id + '/verify', {}); await load(true); } catch (e) { toast(errText(e)); } },
  rmphoto: (id) => { S.form.photos.splice(+id, 1); render(); },
  addphoto: (id) => { S.open.photoFor = +id; const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.multiple = true; i.onchange = async () => { const arr = []; for (const f of [...i.files].slice(0, 4)) { try { arr.push(await shrink(f)); } catch (_) {} } if (arr.length) { try { await api('POST', '/api/w/products/' + id + '/photos', { photos: arr }); toast(t('saved')); await load(true); } catch (e) { toast(errText(e)); } } }; i.click(); },
  addp: () => withBusy(async () => {
    const f = S.form; if (!f.pname || !f.pprice || f.pstock === undefined || f.pstock === '') return toast(t('need'));
    try { await api('POST', '/api/w/products', { name: f.pname, spec: f.pspec || '', price: Number(f.pprice), on_hand: Number(f.pstock), moq: f.pmoq ? Number(f.pmoq) : 1, photos: f.photos || [] });
      for (const k of ['pname', 'pspec', 'pprice', 'pstock', 'pmoq']) delete f[k]; f.photos = []; toast(t('published')); await load(true);
    } catch (e) { toast(errText(e)); }
  }),
  adv: async (id) => { try { await api('POST', '/api/w/orders/' + id + '/advance', { pickup_code: S.form['pc_' + id] || undefined }); delete S.form['pc_' + id]; await load(true); } catch (e) { toast(errText(e)); } },
  wcancel: async (id) => { try { await api('POST', '/api/w/orders/' + id + '/cancel', { reason: 'Cancelled by wholesaler' }); toast(t('cancelled')); await load(true); } catch (e) { toast(errText(e)); } },
  /* admin */
  shopfilter: (id) => { S.open.allShops = id === 'all'; load(); },
  verify: async (id) => { const [sid, action] = id.split(':'); try { await api('POST', '/api/admin/shops/' + sid + '/verify', { action, reason: S.form['reason_' + sid] || undefined }); delete S.form['reason_' + sid]; toast(t('saved')); await load(true); } catch (e) { toast(e.message === 'invalid_reason' ? t('need_reason') : errText(e)); } },
  verifychain: async () => { try { S.d.verify = await api('GET', '/api/admin/audit/verify'); render(); } catch (e) { toast(errText(e)); } },
  resetdemo: async () => { try { await api('POST', '/api/admin/reset-demo', {}); toast(t('saved')); await load(true); } catch (e) { toast(errText(e)); } }
};
document.addEventListener('click', (e) => { const b = e.target.closest('[data-act]'); if (!b || b.disabled) return; const fn = ACT[b.dataset.act]; if (fn) { e.preventDefault(); fn(b.dataset.id); } });
document.addEventListener('input', (e) => { const el = e.target; if (el.dataset && el.dataset.f) S.form[el.dataset.f] = el.value; });
document.addEventListener('change', async (e) => {
  const el = e.target;
  if (el.id === 'aPhotos') { S.form.photos = S.form.photos || []; for (const f of [...el.files]) { if (S.form.photos.length >= 4) { toast(t('e_photos')); break; } try { S.form.photos.push(await shrink(f)); } catch (_) { toast(t('e_img')); } } el.value = ''; render(); }
  else if (el.dataset && el.dataset.proof) { const f = el.files[0]; if (f) { try { S.form['proof_' + el.dataset.proof] = await shrink(f); } catch (_) { toast(t('e_img')); } render(); } }
});
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('form[data-form]'); if (!f) return; e.preventDefault();
  const signup = f.dataset.form === 'signup', v = S.form; S.authErr = '';
  await withBusy(async () => {
    try {
      const m = signup ? await api('POST', '/api/signup', { role: v.role || 'retailer', name: v.name || '', phone: v.phone || '', password: v.password || '', shop_name: v.shop_name || '', city: v.city || '', gstin: (v.role === 'wholesaler' ? (v.gstin || '') : undefined) })
        : await api('POST', '/api/login', { phone: v.phone || '', password: v.password || '' });
      S.busy = false; await enter(m);
    } catch (e) { S.authErr = errText(e); }
  });
});
boot();
})();
