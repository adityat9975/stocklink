'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { open, tx, audit } = require('./lib/db');
const A = require('./lib/auth');

const DEMO_PASSWORD = 'Demo@1234';
const DEMO_CODE = 'K7QM3XRP';
const DAY = 86400000, MIN = 60000;
const IMG = (n) => { try { return fs.readFileSync(path.join(__dirname, 'seed', 'images', n)); } catch (_) { return null; } };

function ensureAdmin(db, cfg) {
  const { phone, password, name } = cfg.admin || {};
  if (cfg.demo || !phone || !password) return false;
  if (password.length < 12) throw new Error('ADMIN_PASSWORD must be at least 12 characters');
  if (db.prepare('SELECT 1 FROM users WHERE phone=?').get(phone)) return false;
  tx(db, () => {
    const uid = Number(db.prepare('INSERT INTO users(phone,name,role,pass_hash,tutorial_done,created_at) VALUES(?,?,?,?,1,?)').run(phone, name || 'Platform Admin', 'admin', A.hashPasswordSync(password), Date.now()).lastInsertRowid);
    audit(db, { actorLabel: 'system', action: 'admin_created', entity: 'user', entityId: uid });
  });
  console.log('Super admin created for', phone);
  return true;
}

function seedDemoIfEmpty(db, cfg) {
  if (db.prepare('SELECT COUNT(*) n FROM users').get().n === 0) seedDemo(db, cfg);
}
function resetDemo(db, cfg) {
  tx(db, () => {
    for (const t of ['order_history', 'order_items', 'orders', 'media', 'products', 'code_attempts', 'invite_codes', 'connections', 'sessions', 'shops', 'users', 'audit_logs'])
      db.exec('DELETE FROM ' + t);
    db.exec(`DELETE FROM sqlite_sequence WHERE name IN ('audit_logs')`);
  });
  seedDemo(db, cfg);
}

function seedDemo(db, cfg) {
  const q = (s) => db.prepare(s);
  const now = Date.now();
  const hash = A.hashPasswordSync(DEMO_PASSWORD);
  const secretFile = path.join(path.dirname(cfg.dbPath), 'secret.key');
  let secret = cfg.secret || (fs.existsSync(secretFile) ? fs.readFileSync(secretFile, 'utf8').trim() : null);
  if (!secret) { secret = require('node:crypto').randomBytes(32).toString('hex'); fs.mkdirSync(path.dirname(secretFile), { recursive: true }); fs.writeFileSync(secretFile, secret, { mode: 0o600 }); }
  tx(db, () => {
    const user = (phone, name, role) => Number(q('INSERT INTO users(phone,name,role,pass_hash,created_at) VALUES(?,?,?,?,?)').run(phone, name, role, hash, now - 20 * DAY).lastInsertRowid);
    const shop = (owner, type, name, city, ver, extra = {}) => Number(q('INSERT INTO shops(owner_id,type,name,city,gstin,upi_id,verification,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .run(owner, type, name, city, extra.gstin || null, extra.upi || null, ver, now - 20 * DAY).lastInsertRowid);
    const uAdmin = user('9000000001', 'Platform Admin', 'admin');
    q('UPDATE users SET tutorial_done=0 WHERE id=?').run(uAdmin);
    const uSharma = user('9000000002', 'Anil Sharma', 'wholesaler');
    const uPatel = user('9000000003', 'Kiran Patel', 'wholesaler');
    const uRahul = user('9000000004', 'Rahul Deshmukh', 'retailer');
    const uVerma = user('9000000005', 'Sanjay Verma', 'retailer');
    const uKul = user('9000000006', 'Meera Kulkarni', 'retailer');
    const sSharma = shop(uSharma, 'wholesaler', 'Sharma Traders', 'Pune', 'approved', { gstin: '27ABCDE1234F1Z0', upi: 'sharma.traders@okbank' });
    shop(uPatel, 'wholesaler', 'Patel Bearings & Tools', 'Ahmedabad', 'pending', { gstin: '24PQRSX5678L1Z2' });
    const sRahul = shop(uRahul, 'retailer', 'Rahul Auto Spares', 'Nashik', 'approved');
    const sVerma = shop(uVerma, 'retailer', 'Verma Hardware', 'Pune', 'approved');
    shop(uKul, 'retailer', 'Kulkarni Machinery', 'Kolhapur', 'approved');
    q('INSERT INTO connections(wholesaler_shop_id,retailer_shop_id,status,source,credit_allowed,requested_at,decided_at) VALUES(?,?,?,?,1,?,?)').run(sSharma, sRahul, 'approved', 'invite_code', now - 15 * DAY, now - 15 * DAY);
    q('INSERT INTO connections(wholesaler_shop_id,retailer_shop_id,status,source,requested_at) VALUES(?,?,?,?,?)').run(sSharma, sVerma, 'pending', 'request', now - 2 * 3600000);
    if (secret) q('INSERT INTO invite_codes(shop_id,code_hash,hint,max_uses,uses,expires_at,auto_approve,created_at) VALUES(?,?,?,?,?,?,0,?)')
      .run(sSharma, A.codeHash(DEMO_CODE, secret), DEMO_CODE.slice(-2), 50, 1, now + 365 * DAY, now - 15 * DAY);

    const defs = [
      ['6205-2RS ball bearing', '25 x 52 x 15 mm, sealed, deep groove', 185, 24, 1, 'pc', 1, 'bearing.jpg', 4 * MIN],
      ['32208 taper roller bearing', '40 x 80 x 24.75 mm', 640, 6, 0, 'pc', 1, 'taper.jpg', 11 * MIN],
      ['B-52 V-belt', 'Section B, 52 in outside length', 210, 40, 2, 'pc', 2, 'belt.jpg', 26 * MIN],
      ['Roller chain 08B-1', 'Pitch 12.7 mm, 3 m length', 1150, 3, 0, 'pc', 1, 'chain.jpg', 52 * MIN],
      ['Bearing grease 400 g', 'Lithium complex, cartridge', 320, 0, 0, 'pc', 1, 'grease.jpg', 95 * MIN],
      ['UCP205 pillow block', 'Cast iron housing with 25 mm bearing', 540, 14, 0, 'pc', 1, 'pillow.jpg', 8 * MIN],
      ['Timing belt HTD 5M-450', 'Width 15 mm, 90 teeth', 380, 22, 0, 'pc', 1, 'timing.jpg', 19 * MIN]
    ];
    const pid = [];
    defs.forEach((d, i) => {
      const id = Number(q('INSERT INTO products(shop_id,name,spec,price_paise,on_hand,reserved,unit,moq,is_new,stock_verified_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        .run(sSharma, d[0], d[1], d[2] * 100, d[3], d[4], d[5], d[6], i < 3 || i === 5 ? 1 : 0, now - d[8], now - (10 - i) * DAY).lastInsertRowid);
      pid.push(id);
      const img = IMG(d[7]); if (img) q('INSERT INTO media(product_id,mime,data,sort,created_at) VALUES(?,?,?,0,?)').run(id, 'image/jpeg', img, now);
    });
    const order = (no, rid, uid, status, items, mode, ful, extra = {}) => {
      const sub = items.reduce((s, [pi, qty]) => s + defs[pi][2] * 100 * qty, 0);
      const oid = Number(q('INSERT INTO orders(no,wholesaler_shop_id,retailer_shop_id,placed_by,status,fulfilment,address,pickup_code,payment_mode,utr,subtotal_paise,idem_key,reserve_expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(no, sSharma, rid, uid, status, ful, ful === 'home' ? 'Shop 4, MIDC Road, Nashik 422010' : null, A.makeCode().slice(0, 6), mode, extra.utr || null, sub, 'seed-' + no, extra.exp || null, now - (extra.age || 3600000), now - (extra.age || 3600000) + 600000).lastInsertRowid);
      for (const [pi, qty] of items) q('INSERT INTO order_items(order_id,product_id,name_snapshot,unit_price_paise,qty) VALUES(?,?,?,?,?)').run(oid, pid[pi], defs[pi][0], defs[pi][2] * 100, qty);
      for (const st of (extra.history || [status])) q('INSERT INTO order_history(order_id,status,actor_user_id,note,ts) VALUES(?,?,?,?,?)').run(oid, st, uid, null, now - (extra.age || 3600000));
    };
    order('SL-1001', sRahul, uRahul, 'paid', [[0, 4]], 'upi', 'home', { utr: 'UTR412908877151', age: 38 * MIN, exp: now + 20 * 3600000, history: ['received', 'paid'] });
    order('SL-1002', sRahul, uRahul, 'completed', [[1, 2], [3, 1]], 'credit', 'pickup', { age: 6 * DAY, history: ['received', 'paid', 'packed', 'dispatched', 'completed'] });
    order('SL-1003', sRahul, uRahul, 'received', [[2, 2]], 'credit', 'pickup', { age: 12 * MIN });

    const L = (actor, label, action, entity, id, detail) => audit(db, { actorId: actor, actorLabel: label, action, entity, entityId: id, detail, ip: '127.0.0.1' });
    L(uSharma, 'Anil Sharma', 'signup', 'shop', sSharma, 'wholesaler Sharma Traders');
    L(uAdmin, 'Platform Admin', 'shop_approve', 'shop', sSharma, 'Sharma Traders');
    L(uRahul, 'Rahul Deshmukh', 'joined_with_invite', 'shop', sSharma, 'status pending');
    L(uSharma, 'Anil Sharma', 'connection_approve', 'connection', 1, 'Rahul Auto Spares');
    L(uSharma, 'Anil Sharma', 'product_created', 'product', pid[0], defs[0][0] + ' stock 24');
    L(uRahul, 'Rahul Deshmukh', 'order_placed', 'order', 1, 'SL-1001 total 74000 items 1');
    L(uVerma, 'Sanjay Verma', 'access_requested', 'shop', sSharma, '');
    L(uPatel, 'Kiran Patel', 'signup', 'shop', 2, 'wholesaler Patel Bearings & Tools');
  });
  console.log('Demo data loaded. Demo password for all accounts:', DEMO_PASSWORD);
}

module.exports = { ensureAdmin, seedDemoIfEmpty, seedDemo, resetDemo, DEMO_PASSWORD, DEMO_CODE };

if (require.main === module) {
  const { loadConfig } = require('./server');
  const cfg = loadConfig(); cfg.demo = true;
  fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
  const db = open(cfg.dbPath);
  if (process.argv.includes('--reset')) resetDemo(db, cfg); else seedDemoIfEmpty(db, cfg);
}
